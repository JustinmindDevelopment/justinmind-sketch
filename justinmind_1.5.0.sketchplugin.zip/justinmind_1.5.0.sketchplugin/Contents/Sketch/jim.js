@import 'fileUtils.js'
@import 'utils.js'

var mapID = {};
var invalidXMLCharacterSet;
function createJustinmindXMLData(folderURL,sketchData){
  mapID = {};
  createInvalidXMLCharacterSet();

  for (var i = 0; i < sketchData.length; i++) {
    var artboardData = sketchData[i];
    createScreenFromArtboard(folderURL,i,artboardData);
  }
}

function createScreenFromArtboard(folderURL,index, artboardData){
  var screenID =  createNewUUID();
  var screenXMLPath = folderURL.path().stringByAppendingPathComponent("screens").stringByAppendingPathComponent(screenID+".xml");
  var xmlDoc = createScreenXMLDoc(screenID,index, artboardData);
  writeXMLDoc(xmlDoc,screenXMLPath);
  if(index===0)
    setProjectProperties(folderURL,screenID);
}


function createScreenXMLDoc(id,index, artboardData){
  var root = NSXMLNode.elementWithName("screen");
  var xmlDoc = NSXMLDocument.alloc().initWithRootElement(root);
  xmlDoc.setVersion("1.0");
  xmlDoc.setCharacterEncoding("UTF-8");

  var dateFormatter = NSDateFormatter.alloc().init();
  dateFormatter.setDateFormat(@"dd/MM/yyyy HH:mm:ss");
  var date = dateFormatter.stringFromDate(NSDate.date());
  root.addChild(NSXMLNode.elementWithName("parentCode"));
  root.addChild(NSXMLNode.elementWithName_stringValue("folderPosition",index+""));
  root.addChild(NSXMLNode.elementWithName_stringValue("name",artboardData.name));
  root.addChild(NSXMLNode.elementWithName_stringValue("code",id));
  root.addChild(NSXMLNode.elementWithName_stringValue("templateID","f39803f7-df02-4169-93eb-7547fb8c961a"));
  root.addChild(NSXMLNode.elementWithName_stringValue("date",date));
  root.addChild(NSXMLNode.elementWithName_stringValue("note",""));
  root.addChild(NSXMLNode.elementWithName_stringValue("legend-item",""));
  root.addChild(NSXMLNode.elementWithName_stringValue("pageAlignment","LEFT"));
  root.addChild(NSXMLNode.elementWithName_stringValue("orientation",selectedOrientation.toUpperCase()));

  var jimDevice = getJustinmindDeviceType();
  if(jimDevice.isWeb==true){
    root.addChild(NSXMLNode.elementWithName_stringValue("width",artboardData.width));
    root.addChild(NSXMLNode.elementWithName_stringValue("height",artboardData.height));
    root.addChild(NSXMLNode.elementWithName_stringValue("backgroundGrowth","BOTH"));
  }else{
    root.addChild(NSXMLNode.elementWithName_stringValue("width",jimDevice.width));
    root.addChild(NSXMLNode.elementWithName_stringValue("height",jimDevice.height));
    root.addChild(NSXMLNode.elementWithName_stringValue("backgroundGrowth","VERTICAL"));
  }

  root.addChild(NSXMLNode.elementWithName_stringValue("device",jimDevice.type));
  root.addChild(NSXMLNode.elementWithName("guides"));
  var node =  NSXMLNode.elementWithName("item-group");
  node.addAttribute(NSXMLNode.attributeWithName_stringValue("id",createNewUUID()));
  node.addAttribute(NSXMLNode.attributeWithName_stringValue("visible","true"));

  createContainerChildrenNodes(node,artboardData.items,0);

  node.addChild(createCanvasStyleNode(artboardData));
  root.addChild(node);
  root.addChild(NSXMLNode.elementWithName("Events"));

  return xmlDoc;
}

function createContainerChildrenNodes(node,childrenData,parentRotation){
/*  if(node.rotation)
    parentRotation += node.rotation;
  parentRotation = getJustinmindRotation(parentRotation);*/
  for (var i = 0; i < childrenData.length; i++) {
    var childData = childrenData[i];
    var type =  childData.type;
    var childNode;

    switch(type){
      case "text":
        childNode = createTextNode(childData,parentRotation);
        break;
      case "image":
        childNode = createImageNode(childData,parentRotation);
        break;
      case "svg":
        if(childData.name.startsWith("in_")){
          childData.name=childData.name.split("_").pop();
          image = createSVGNode(childData,parentRotation);
          childData.type="inputText";
          childData.name="in_"+childData.name;
          childData.rotation="0";
          childData.radius="0";
          childData.fill = {
            'color':"0r0g0b100a",
            'type':"color"
          };
          var childNode = createRectangleNode(childData,parentRotation);
          node.addChild(image)
        }else
          childNode= createSVGNode(childData,parentRotation);
        break;
      case "line":
        childNode = createLineNode(childData,parentRotation);
        break;
      case "rectangle":
        childNode = createRectangleNode(childData,parentRotation);
        break;
      case "inputText":
        childNode = createRectangleNode(childData,parentRotation);
        break;
      case "ellipse":
        childNode = createEllipseNode(childData,parentRotation);
        break;
      case "group":
        childNode = createGroupNode(childData,parentRotation);
        break;
    }
    if(childNode)
      node.addChild(childNode);
  }
}

function createCanvasStyleNode(artboardData){
  var styleNode =  NSXMLNode.elementWithName("style");
  styleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFCanvas"));

  styleNode.addChild(createDimensionNodeWH(0,0));
  styleNode.addChild(createPositionNodeXY(0,0));

  var backgroundNode = NSXMLNode.elementWithName("BackgroundStyle");
  if(artboardData.background){
    backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("type","color"));
    backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("value",artboardData.background));
  }else{
    backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("type","color"));
    backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("value","0r0g0b0a"));
    backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("disabledColor","true"));
  }
  styleNode.addChild(backgroundNode);

  styleNode.addChild(createTransparencyVNode(0));

  return styleNode;
}

function setProjectProperties(folderURL,homeScreenID){
  var nsURLProperties = NSURL.URLWithString_relativeToURL("properties.xml",folderURL);
  var xmlDoc = NSXMLDocument.alloc().initWithContentsOfURL_options_error(nsURLProperties,NSXMLDocumentTidyXML,null);

  var jimDevice = getJustinmindDeviceType();

  var root = xmlDoc.rootElement();
  var children = root.children();
  for (var i = 0; i < children.length; i++) {
    var childNode = children[i];
    if(childNode.name()=="prototypeDevice")
      childNode.setStringValue(jimDevice.type);
    else if(childNode.name()=="homeScreenCode")
      childNode.setStringValue(homeScreenID);
    else if(childNode.name()=="canvasOrientation")
      childNode.setStringValue(selectedOrientation.toUpperCase());
    else if(childNode.name()=="canvasSize"){
       childNode.attributeForName("w").setStringValue(jimDevice.width);
       childNode.attributeForName("h").setStringValue(jimDevice.height);
    }
  }
  var externalAppNode =  NSXMLNode.elementWithName("externalApp");
  externalAppNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","sketch"));
  externalAppNode.addChild(NSXMLNode.elementWithName_stringValue("appVersion",getSketchVersion()));
  externalAppNode.addChild(NSXMLNode.elementWithName_stringValue("pluginVersion",pluginVersion));
  root.addChild(externalAppNode);
  writeXMLDoc(xmlDoc,nsURLProperties.path());
  setSimulationDeviceProperties(folderURL,jimDevice);
  setLibrariesProperties(folderURL,jimDevice);
}

function setSimulationDeviceProperties(folderURL,jimDevice){
  var nsURLProperties = NSURL.URLWithString_relativeToURL("simulation/simulation.xml",folderURL);

  var xmlDoc = NSXMLDocument.alloc().initWithContentsOfURL_options_error(nsURLProperties,NSXMLDocumentTidyXML,null);

  var root = xmlDoc.rootElement();
  var children = root.children();

  for (var i = 0; i < children.length; i++) {
    var childNode = children[i];
    if(childNode.name()=="device")
      childNode.setStringValue(jimDevice.type);
    else if(childNode.name()=="widthValue")
      childNode.setStringValue(jimDevice.width);
    else if(childNode.name()=="heightValue")
      childNode.setStringValue(jimDevice.height);
    else if(childNode.name()=="orientation")
      childNode.setStringValue(selectedOrientation.toLowerCase());
  }
  root.addChild(NSXMLNode.elementWithName_stringValue("startWidthMode","true"));
  writeXMLDoc(xmlDoc,nsURLProperties.path());
}

function setLibrariesProperties(folderURL,jimDevice){
  var mapLibraries = getAvailableLibraries();

  var nsURLProperties = NSURL.URLWithString_relativeToURL("widgetLibraries.xml",folderURL);

  var xmlDoc = NSXMLDocument.alloc().initWithContentsOfURL_options_error(nsURLProperties,NSXMLDocumentTidyXML,null);

  var root = xmlDoc.rootElement();

  if(jimDevice.isWeb==true){
    root.addChild(mapLibraries["basic"]);
    root.addChild(mapLibraries["webComponents"]);
  } else if(jimDevice.isIphone==true){
    root.addChild(mapLibraries["basic"]);
    root.addChild(mapLibraries["iphone"]);
  } else  if(jimDevice.isAndroid=true){
    root.addChild(mapLibraries["basic"]);
    root.addChild(mapLibraries["android"]);
  }

  writeXMLDoc(xmlDoc,nsURLProperties.path());
}

function createTextNode(textData,parentRotation){
  var textNode =  NSXMLNode.elementWithName("rich-text");
  textNode.addAttribute(NSXMLNode.attributeWithName_stringValue("id",createNewUUID()));
  textNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hidden",textData.visible ? "false" : "true"));
  textNode.addAttribute(NSXMLNode.attributeWithName_stringValue("lockType","none"));
  textNode.addAttribute(NSXMLNode.attributeWithName_stringValue("onTop","false"));
  textNode.addAttribute(NSXMLNode.attributeWithName_stringValue("visible",textData.visible ? "true" : "false"));

  textNode.addChild(NSXMLNode.elementWithName_stringValue("text",removeInvalidCharacters(textData.text)));

  var styleNode = NSXMLNode.elementWithName("style");
  styleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFRichText"));

  var dimensionNode = createDimensionNode(textData.size);
  dimensionNode.addAttribute(NSXMLNode.attributeWithName_stringValue("autofit","false"));
  styleNode.addChild(dimensionNode);

  styleNode.addChild(createPositionNode(textData.relativePosition));
  styleNode.addChild(createBackgroundNode(textData.background));

  styleNode.addChild(createDefaultBorderNode(false));
  styleNode.addChild(createTextStyleNode(textData));
  styleNode.addChild(createFontStyleNode(textData.fontData));
  styleNode.addChild(createTransparencyNode(textData.transparency));
  //textData.rotation += parentRotation;
  //textData.rotation = getJustinmindRotation(textData.rotation);
  styleNode.addChild(createRotationNode(getJustinmindRotation(textData.rotation)));
  styleNode.addChild(createShadowNode(textData.textShadow,false));
  textNode.addChild(styleNode);

  var rangeListNode = NSXMLNode.elementWithName("rich-text-range-list");

  for (var i = 0; i < textData.ranges.length; i++) {
    var rangeData = textData.ranges[i];
    var rangeNode = NSXMLNode.elementWithName("text-range");
    rangeNode.addAttribute(NSXMLNode.attributeWithName_stringValue("text-range-start",rangeData.start+""));
    rangeNode.addAttribute(NSXMLNode.attributeWithName_stringValue("text-range-end",rangeData.end+""));

    var rangeStyleNode = NSXMLNode.elementWithName("style");
    rangeStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFTextRange"));
    rangeStyleNode.addChild(createTextStyleNode(rangeData));
    rangeStyleNode.addChild(createFontStyleNode(rangeData.fontData));
    rangeNode.addChild(rangeStyleNode);
    rangeListNode.addChild(rangeNode);
  }

  textNode.addChild(rangeListNode);
  var userID = calculateValidName(textData.name);
  textNode.addChild(NSXMLNode.elementWithName_stringValue("userID",(userID===undefined || userID==="") ? "Paragraph":userID));

  return textNode;
}

function createImageNode(imageData,parentRotation){

  var imageNode =  NSXMLNode.elementWithName("image");
  imageNode.addAttribute(NSXMLNode.attributeWithName_stringValue("id",createNewUUID()));
  imageNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hidden",imageData.visible ? "false" : "true"));
  imageNode.addAttribute(NSXMLNode.attributeWithName_stringValue("lockType","none"));
  imageNode.addAttribute(NSXMLNode.attributeWithName_stringValue("onTop","false"));
  imageNode.addAttribute(NSXMLNode.attributeWithName_stringValue("visible",imageData.visible ? "true" : "false"));


  imageNode.addChild(NSXMLNode.elementWithName_stringValue("image-name",imageData.filename));
  imageNode.addChild(NSXMLNode.elementWithName_stringValue("original-name",imageData.filename));

  var styleNode = NSXMLNode.elementWithName("style");
  styleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFImage"));

  styleNode.addChild(createDimensionNode(imageData.size));
  styleNode.addChild(createPositionNode(imageData.relativePosition));
  styleNode.addChild(createDefaultBorderNode(false));

  styleNode.addChild(createTransparencyVNode(0));

//  imageData.rotation += parentRotation;
  //imageData.rotation = getJustinmindRotation(imageData.rotation);
  //styleNode.addChild(createRotationVNode(0));
  styleNode.addChild(createRotationNode(0));
  styleNode.addChild(createEmptyShadowNode());

  var backgroundNode = NSXMLNode.elementWithName("SVGBackgroundStyle");
  backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("isSVG","false"));
  backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bgColor","0r0g0b"));
  backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hasColor","false"));
  styleNode.addChild(backgroundNode);

  imageNode.addChild(styleNode);
  imageNode.addChild(NSXMLNode.elementWithName_stringValue("userID",calculateValidName(imageData.name)));
  return imageNode;
}

/*
<image id="1deb5ccf-d64c-4014-9dcf-43465a165dd8" hidden="false" onTop="false" visible="true">
      <image-name type="svg" preserveRatio="false">3c61ed62-24ba-4f8d-b045-bb79db46f672@2x.png</image-name>
      <original-name>cartman.png</original-name>
      <style name="LnFImage">
        <DimensionStyle width="375.0000000000002" height="356.3255337352771" widthType="px" heightType="px" lockWidth="false" lockHeight="false" />
        <PositioningStyle left="9.0" top="100.0" pinLeft="none" pinTop="none" lockTop="false" lockLeft="false" />
        <BorderStyle topRadius="0.0" rightRadius="0.0" bottomRadius="0.0" leftRadius="0.0" leftColor="0r0g0b0a" topColor="0r0g0b0a" rightColor="0r0g0b0a" bottomColor="0r0g0b0a" leftStyle="solid" topStyle="solid" rightStyle="solid" bottomStyle="solid" leftWidth="1.0" topWidth="1.0" rightWidth="1.0" bottomWidth="1.0" topDisabled="true" rightDisabled="true" bottomDisabled="true" leftDisabled="true" />
        <TransparencyStyle value="0" />
        <RotationStyle angle="0.0" />
        <SVGBackgroundStyle isSVG="true" bgColor="0r0g0b0a" hasColor="false" />
        <MarginStyle top="0" left="0" bottom="0" right="0" />
        <BlendingStyle blend="Default" />
        <EffectStyle />
      </style>
      <image-flip horizontal="false" vertical="false" />
      <userID>Image 1</userID>
      <isDefault>false</isDefault>
      <modelID>Image_1</modelID>
    </image>*/

function createSVGNode(svgData,parentRotation){
  var svgNode =  NSXMLNode.elementWithName("image");
  svgNode.addAttribute(NSXMLNode.attributeWithName_stringValue("id",createNewUUID()));
  svgNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hidden",svgData.visible ? "false" : "true"));
  svgNode.addAttribute(NSXMLNode.attributeWithName_stringValue("lockType","none"));
  svgNode.addAttribute(NSXMLNode.attributeWithName_stringValue("onTop","false"));
  svgNode.addAttribute(NSXMLNode.attributeWithName_stringValue("visible",svgData.visible ? "true" : "false"));

  var imageNameNode = NSXMLNode.elementWithName_stringValue("image-name",svgData.filename);
  imageNameNode.addAttribute(NSXMLNode.attributeWithName_stringValue("type","svg"));
  imageNameNode.addAttribute(NSXMLNode.attributeWithName_stringValue("preserveRatio","false"));
  svgNode.addChild(imageNameNode);
  svgNode.addChild(NSXMLNode.elementWithName_stringValue("original-name",svgData.filename));

  var styleNode = NSXMLNode.elementWithName("style");
  styleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFImage"));

  styleNode.addChild(createDimensionNode(svgData.size));
  styleNode.addChild(createPositionNode(svgData.relativePosition));
  styleNode.addChild(createDefaultBorderNode(false));
  styleNode.addChild(createTransparencyVNode(0));
  //svgData.rotation += parentRotation;
  //svgData.rotation = getJustinmindRotation(svgData.rotation);
  //styleNode.addChild(createRotationVNode(0));
  styleNode.addChild(createRotationNode(0));
  styleNode.addChild(createEmptyShadowNode());

  var backgroundNode = NSXMLNode.elementWithName("SVGBackgroundStyle");
  backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("isSVG","true"));
  backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bgColor","0r0g0b"));
  backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hasColor","false"));
  styleNode.addChild(backgroundNode);

  svgNode.addChild(styleNode);
  svgNode.addChild(NSXMLNode.elementWithName_stringValue("userID",calculateValidName(svgData.name)));
  return svgNode;
}

function createRectangleNode(rectangleData,parentRotation){
  var rectangleNode =  NSXMLNode.elementWithName("rectangle");
  if(rectangleData.type == "inputText") rectangleNode =  NSXMLNode.elementWithName("attribute-form");
  rectangleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("id",createNewUUID()));
  rectangleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hidden",rectangleData.visible ? "false" : "true"));
  rectangleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("auto-fit","false"));
  if(rectangleData.type == "inputText") rectangleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("writable","true"));
  rectangleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("lockType","none"));
  rectangleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("onTop","false"));
  rectangleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("visible",rectangleData.visible ? "true" : "false"));
   if(rectangleData.type == "inputText"){
      rectangleNode.addChild(NSXMLNode.elementWithName_stringValue("attStyle","InputText"));
      rectangleNode.addChild(NSXMLNode.elementWithName_stringValue("type","text"));
   }

  var styleNode = NSXMLNode.elementWithName("style");
  if(rectangleData.type == "inputText") styleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFAttributeForm"));
  else styleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFRectangle"));
  styleNode.addChild(createDimensionNode(rectangleData.size));
  styleNode.addChild(createBackgroundNode(rectangleData.background));

  styleNode.addChild(createPositionNode(rectangleData.relativePosition));
  styleNode.addChild(createBorderNode(rectangleData.border,rectangleData.radius,false,false));
  styleNode.addChild(createDefaultTextStyleNode(rectangleData.type =="inputText"));
  styleNode.addChild(createDefaultFontStyleNode());
  styleNode.addChild(createTransparencyNode(rectangleData.transparency));
  //rectangleData.rotation += parentRotation;
  //rectangleData.rotation = getJustinmindRotation(rectangleData.rotation);

  styleNode.addChild(createRotationNode(getJustinmindRotation(rectangleData.rotation)));
  //styleNode.addChild(createRotationNode(rectangleData.rotation));

  styleNode.addChild(createShadowNode(rectangleData.shadow,true));
  styleNode.addChild(createEmptyMarginNode());

  var paddingNode = NSXMLNode.elementWithName("PaddingStyle");
  if(rectangleData.type =="inputText")
    paddingNode.addAttribute(NSXMLNode.attributeWithName_stringValue("left","5"));
  else
    paddingNode.addAttribute(NSXMLNode.attributeWithName_stringValue("left","0"));
  paddingNode.addAttribute(NSXMLNode.attributeWithName_stringValue("top","0"));
  paddingNode.addAttribute(NSXMLNode.attributeWithName_stringValue("right","0"));
  paddingNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bottom","0"));
  styleNode.addChild(paddingNode);
  rectangleNode.addChild(styleNode);

  var rangeListNode = NSXMLNode.elementWithName("rich-text-range-list");
  var rangeNode = NSXMLNode.elementWithName("text-range");
  rangeNode.addAttribute(NSXMLNode.attributeWithName_stringValue("text-range-start","0"));
  rangeNode.addAttribute(NSXMLNode.attributeWithName_stringValue("text-range-end","0"));
  var rangeStyleNode = NSXMLNode.elementWithName("style");
  rangeStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFTextRange"));
  rangeStyleNode.addChild(createDefaultTextStyleNode(rectangleData.type =="inputText"));
  rangeStyleNode.addChild(createDefaultFontStyleNode());
  rangeNode.addChild(rangeStyleNode);
  rangeListNode.addChild(rangeNode);
  rectangleNode.addChild(rangeListNode);

  if(rectangleData.type =="inputText"){
    rectangleNode.addChild(NSXMLNode.elementWithName_stringValue("defaultValue",""));
    rectangleNode.addChild(NSXMLNode.elementWithName_stringValue("placeholder",""));
  }

  var userid =calculateValidName(rectangleData.name);
  if(rectangleData.type =="inputText")
    rectangleNode.addChild(NSXMLNode.elementWithName_stringValue("userID",userid.split("_").pop()));
  else
    rectangleNode.addChild(NSXMLNode.elementWithName_stringValue("userID",userid));
  return rectangleNode;
}

function createEllipseNode(ellipseData,parentRotation){

  var ellipseNode =  NSXMLNode.elementWithName("ellipse");
  ellipseNode.addAttribute(NSXMLNode.attributeWithName_stringValue("id",createNewUUID()));
  ellipseNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hidden",ellipseData.visible ? "false" : "true"));
  ellipseNode.addAttribute(NSXMLNode.attributeWithName_stringValue("lockType","none"));
  ellipseNode.addAttribute(NSXMLNode.attributeWithName_stringValue("onTop","false"));
  ellipseNode.addAttribute(NSXMLNode.attributeWithName_stringValue("visible",ellipseData.visible ? "true" : "false"));

  var styleNode = NSXMLNode.elementWithName("style");
  styleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFEllipse"));
  styleNode.addChild(createDimensionNode(ellipseData.size));
  styleNode.addChild(createBackgroundNode(ellipseData.background));

  styleNode.addChild(createPositionNode(ellipseData.relativePosition));
  styleNode.addChild(createBorderNode(ellipseData.border,ellipseData.radius,true,false));
  styleNode.addChild(createDefaultTextStyleNode(false));
  styleNode.addChild(createDefaultFontStyleNode());
  styleNode.addChild(createTransparencyNode(ellipseData.transparency));
  //ellipseData.rotation += parentRotation;
  //ellipseData.rotation = getJustinmindRotation(ellipseData.rotation);
  styleNode.addChild(createRotationNode(getJustinmindRotation(ellipseData.rotation)));
  //styleNode.addChild(createRotationNode(ellipseData.rotation));
  styleNode.addChild(createShadowNode(ellipseData.shadow,true));
  styleNode.addChild(createEmptyMarginNode());
  ellipseNode.addChild(styleNode);

  var rangeListNode = NSXMLNode.elementWithName("rich-text-range-list");
  var rangeNode = NSXMLNode.elementWithName("text-range");
  rangeNode.addAttribute(NSXMLNode.attributeWithName_stringValue("text-range-start","0"));
  rangeNode.addAttribute(NSXMLNode.attributeWithName_stringValue("text-range-end","0"));
  var rangeStyleNode = NSXMLNode.elementWithName("style");
  rangeStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFTextRange"));
  rangeStyleNode.addChild(createDefaultTextStyleNode(false));
  rangeStyleNode.addChild(createDefaultFontStyleNode());
  rangeNode.addChild(rangeStyleNode);
  rangeListNode.addChild(rangeNode);

  ellipseNode.addChild(rangeListNode);
  var textNode = NSXMLNode.elementWithName("text");
  ellipseNode.addChild(textNode);

  ellipseNode.addChild(NSXMLNode.elementWithName_stringValue("userID",calculateValidName(ellipseData.name)));
  return ellipseNode;
}


function createLineNode(lineData,parentRotation){

  var lineNode =  NSXMLNode.elementWithName("line");
  lineNode.addAttribute(NSXMLNode.attributeWithName_stringValue("id",createNewUUID()));
  lineNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hidden",lineData.visible ? "false" : "true"));
  lineNode.addAttribute(NSXMLNode.attributeWithName_stringValue("start-marker","NONE"));
  lineNode.addAttribute(NSXMLNode.attributeWithName_stringValue("end-marker","NONE"));
  lineNode.addAttribute(NSXMLNode.attributeWithName_stringValue("lockType","none"));
  lineNode.addAttribute(NSXMLNode.attributeWithName_stringValue("onTop","false"));
  lineNode.addAttribute(NSXMLNode.attributeWithName_stringValue("visible",lineData.visible ? "true" : "false"));

  var styleNode = NSXMLNode.elementWithName("style");
  styleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFSeparationLine"));
  styleNode.addChild(createDimensionNodeWH(lineData.lineLength,lineData.border.width));
  styleNode.addChild(createPositionNode(lineData.relativePosition));
  styleNode.addChild(createBorderNode(lineData.border,lineData.radius,false,true));
  styleNode.addChild(createTransparencyNode(lineData.transparency));
  //lineData.rotation += parentRotation;
    //lineData.rotation = getJustinmindRotation(lineData.rotation);
    styleNode.addChild(createRotationNode(getJustinmindRotation(lineData.rotation)));
  //styleNode.addChild(createRotationNode(lineData.rotation));
  styleNode.addChild(createShadowNode(lineData.shadow,true));
  styleNode.addChild(createEmptyMarginNode());

  lineNode.addChild(styleNode);
  lineNode.addChild(NSXMLNode.elementWithName_stringValue("userID",calculateValidName(lineData.name)));
  return lineNode;
}

function createGroupNode(groupData,parentRotation){
  var groupNode =  NSXMLNode.elementWithName("group-container");
  groupNode.addAttribute(NSXMLNode.attributeWithName_stringValue("id",createNewUUID()));
  groupNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hidden",groupData.visible ? "false" : "true"));
  groupNode.addAttribute(NSXMLNode.attributeWithName_stringValue("lockType","none"));
  groupNode.addAttribute(NSXMLNode.attributeWithName_stringValue("onTop","false"));
  groupNode.addAttribute(NSXMLNode.attributeWithName_stringValue("visible",groupData.visible ? "true" : "false"));

/*  if(groupData.rotation)
   parentRotation += groupData.rotation;
  parentRotation = getJustinmindRotation(parentRotation);*/

  createContainerChildrenNodes(groupNode,groupData.items,parentRotation);

  var styleNode = NSXMLNode.elementWithName("style");
  styleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","LnFGroup"));

  styleNode.addChild(createDimensionNode(groupData.size));
  styleNode.addChild(createPositionNodeXY(0,0));
  styleNode.addChild(createRotationVNode(0));

  groupNode.addChild(styleNode);
  groupNode.addChild(NSXMLNode.elementWithName_stringValue("userID",calculateValidName(groupData.name)));
  return groupNode;
}

function createDimensionNode(size){
  return createDimensionNodeWH(size.width,size.height);
}

function createDimensionNodeWH(width,height){
  var dimensionNode = NSXMLNode.elementWithName("DimensionStyle");
  dimensionNode.addAttribute(NSXMLNode.attributeWithName_stringValue("width",Math.round(width).toString()));
  dimensionNode.addAttribute(NSXMLNode.attributeWithName_stringValue("height",Math.round(height).toString()));
  return dimensionNode;
}

function createPositionNode(position){
  return createPositionNodeXY(position.x,position.y);
}

function createPositionNodeXY(x,y){
  var positionNode = NSXMLNode.elementWithName("PositioningStyle");
  positionNode.addAttribute(NSXMLNode.attributeWithName_stringValue("left",Math.round(x).toString()));
  positionNode.addAttribute(NSXMLNode.attributeWithName_stringValue("top",Math.round(y).toString()));
  return positionNode;
}

function createBackgroundNode(background){
  var backgroundNode = NSXMLNode.elementWithName("BackgroundStyle");
  if(background){
    if(background.type=="color"){
      backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("type","color"));
      backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("value",background.color));
    }else if(background.type=="image"){
      backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("type","color"));
      backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("value","0r0g0b0a"));
      backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("disabledColor","true"));
      backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("disabledImage","false"));
      var bgImageNode = NSXMLNode.elementWithName("image");
      bgImageNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bgImType",background.image.type));
      bgImageNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bgImHAlign",(background.image.type =="REPEAT")?"BEGINNING":"CENTER"));
      bgImageNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bgImVAlign",(background.image.type =="REPEAT")?"BEGINNING":"CENTER"));
      var valueImNode = NSXMLNode.elementWithName("value");
      valueImNode.addAttribute(NSXMLNode.attributeWithName_stringValue("original-name",background.image.filename));
      valueImNode.setStringValue(background.image.filename);
      bgImageNode.addChild(valueImNode);
      backgroundNode.addChild(bgImageNode);
    }else{
      backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("type",(background.type =="linear")?"linear-gradient":"radial-gradient"));
      var gradientNode = NSXMLNode.elementWithName((background.type =="linear")?"linear-gradient":"radial-gradient");
      if(background.type =="linear"){
        gradientNode.addAttribute(NSXMLNode.attributeWithName_stringValue("startX",background.from.x.toString()));
        gradientNode.addAttribute(NSXMLNode.attributeWithName_stringValue("startY",background.from.y.toString()));
        gradientNode.addAttribute(NSXMLNode.attributeWithName_stringValue("endX",background.to.y.toString()));
        gradientNode.addAttribute(NSXMLNode.attributeWithName_stringValue("endY",background.to.y.toString()));
      }else{
        gradientNode.addAttribute(NSXMLNode.attributeWithName_stringValue("x",background.from.x.toString()));
        gradientNode.addAttribute(NSXMLNode.attributeWithName_stringValue("y",background.from.y.toString()));
        gradientNode.addAttribute(NSXMLNode.attributeWithName_stringValue("radius",background.radius.toString()));
      }
      background.stops.forEach(stop=>{
        var stopNode = NSXMLNode.elementWithName("stop");
        stopNode.addAttribute(NSXMLNode.attributeWithName_stringValue("color",stop.color));
        stopNode.addAttribute(NSXMLNode.attributeWithName_stringValue("position",stop.position.toString()));
        gradientNode.addChild(stopNode);
      });
      backgroundNode.addChild(gradientNode);
    }
  }else{
    backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("type","color"));
    backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("value","0r0g0b0a"));
    backgroundNode.addAttribute(NSXMLNode.attributeWithName_stringValue("disabledColor","true"));
  }

  return backgroundNode;
  /*<BackgroundStyle type="radial-gradient" alpha="0" disabledColor="true" disabledImage="false">
          <image alpha="0" bgImType="STRETCH" bgImHAlign="CENTER" bgImVAlign="BEGINNING">
            <value original-name="GolemCard.png">0f866b63-3ef2-4b40-80aa-828ed64d53c2.png</value>
          </image>
          */
}


function createDefaultBorderNode(allEqual){
  var borderNode = NSXMLNode.elementWithName("BorderStyle");
  if(allEqual){
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("color","0r0g0b"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("style","none"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("width","1"));
  }else{
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("radius","0"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("leftColor","0r0g0b"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("topColor","0r0g0b"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("rightColor","0r0g0b"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bottomColor","0r0g0b"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("leftStyle","none"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("topStyle","none"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("rightStyle","none"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bottomStyle","none"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("leftWidth","1"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("topWidth","1"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("rightWidth","1"));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bottomWidth","1"));
  }
  return borderNode;
}

function createBorderNode(border,radius,allEqual,onlyTop){
  var borderNode;
  if(!border)
    borderNode = createDefaultBorderNode(allEqual);
  else{
    borderNode = NSXMLNode.elementWithName("BorderStyle");
    if(allEqual){
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("color",border.color));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("style",border.style));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("width",Math.round(border.width).toString()));
    }else{
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("topColor",border.color));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("rightColor",border.color));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bottomColor",border.color));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("leftColor",border.color))
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("topStyle",border.style));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("rightStyle",onlyTop?"none":border.style));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bottomStyle",onlyTop?"none":border.style));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("leftStyle",onlyTop?"none":border.style));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("topWidth",Math.round(border.width).toString()));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("leftWidth",onlyTop?"1":Math.round(border.width).toString()));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("rightWidth",onlyTop?"1":Math.round(border.width).toString()));
      borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bottomWidth",onlyTop?"1":Math.round(border.width).toString()));
    }
  }

  if(!radius)
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("radius","0"));
  else if(!radius.all){
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("topRadius",radius.tl));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("rightRadius",radius.tr));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bottomRadius",radius.br));
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("leftRadius",radius.bl));
  }else{
    borderNode.addAttribute(NSXMLNode.attributeWithName_stringValue("radius",radius.all));
  }

  return borderNode;
}

function createEmptyShadowNode(){
  var shadowNode = NSXMLNode.elementWithName("ShadowStyle");
  var boxNode = NSXMLNode.elementWithName("Box");
  boxNode.addAttribute(NSXMLNode.attributeWithName_stringValue("enable","false"));
  shadowNode.addChild(boxNode);
  return shadowNode;
}

function createShadowNode(shadow,isBox){
  var shadowStyleNode = NSXMLNode.elementWithName("ShadowStyle");
  var shadowNode = createShadowNamedNode(shadow,isBox ? "Box":"Text");
  var nonShadowNode = NSXMLNode.elementWithName(isBox ? "Text":"Box");
  nonShadowNode.addAttribute(NSXMLNode.attributeWithName_stringValue("enable","false"));
  shadowStyleNode.addChild(shadowNode);
  shadowStyleNode.addChild(nonShadowNode);
  return shadowStyleNode;
}

function createShadowNamedNode(shadow,name){
  var shadowNode = NSXMLNode.elementWithName(name);
  if(shadow!=null){
    shadowNode.addAttribute(NSXMLNode.attributeWithName_stringValue("enable","true"));
    shadowNode.addAttribute(NSXMLNode.attributeWithName_stringValue("global","false"));
    shadowNode.addAttribute(NSXMLNode.attributeWithName_stringValue("blur",shadow.blur));
    shadowNode.addAttribute(NSXMLNode.attributeWithName_stringValue("distance",shadow.distance));
    shadowNode.addAttribute(NSXMLNode.attributeWithName_stringValue("dist",shadow.dist));
    shadowNode.addAttribute(NSXMLNode.attributeWithName_stringValue("angle",shadow.angle));
    shadowNode.addAttribute(NSXMLNode.attributeWithName_stringValue("color",shadow.color));
  }else
    shadowNode.addAttribute(NSXMLNode.attributeWithName_stringValue("enable","false"));
  return shadowNode;
}

function createEmptyMarginNode(){
  var marginNode = NSXMLNode.elementWithName("MarginStyle");
  marginNode.addAttribute(NSXMLNode.attributeWithName_stringValue("left","0"));
  marginNode.addAttribute(NSXMLNode.attributeWithName_stringValue("top","0"));
  marginNode.addAttribute(NSXMLNode.attributeWithName_stringValue("right","0"));
  marginNode.addAttribute(NSXMLNode.attributeWithName_stringValue("bottom","0"));
  return marginNode;
}

function createTransparencyNode(transparency){
  if(transparency !=null)
    return createTransparencyVNode(transparency);
  else
    return createTransparencyVNode(0);
}

function createTransparencyVNode(value){
  var transparencyNode = NSXMLNode.elementWithName("TransparencyStyle");
  transparencyNode.addAttribute(NSXMLNode.attributeWithName_stringValue("value",value.toString()));
  return transparencyNode;
}

function createRotationNode(rotation){
  if(rotation !=null)
    return createRotationVNode(rotation);
  else
    return createRotationVNode(0);
}

function createRotationVNode(value){
  var rotationNode = NSXMLNode.elementWithName("RotationStyle");
  rotationNode.addAttribute(NSXMLNode.attributeWithName_stringValue("angle",Math.round(value).toString()));
  return rotationNode;
}

function createDefaultTextStyleNode(isLeftAlign){
  var textStyleNode = NSXMLNode.elementWithName("TextStyle");
  textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("color","51r51g51b0a"));
  textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hAlign",isLeftAlign?"left":"center"));
  textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("vAlign","center"));
  textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("decoration","none"));
  textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("line-height","18"));
  return textStyleNode;
}

function createTextStyleNode(textData){
  var textStyleNode = NSXMLNode.elementWithName("TextStyle");
  textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("color",textData.text_color));
  textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("hAlign",textData.text_hAlign));
  textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("vAlign","left"));
  textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("decoration",textData.text_decoration));
  if(textData.kerning)
    textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("letter-spacing",textData.kerning));
  if(textData.line_height)
    textStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("line-height",Math.round(textData.line_height).toString()));
  return textStyleNode;
}

function createDefaultFontStyleNode(){
  var fontNode = NSXMLNode.elementWithName("FontStyle");
  fontNode.addAttribute(NSXMLNode.attributeWithName_stringValue("size","10.0"));
  fontNode.addAttribute(NSXMLNode.attributeWithName_stringValue("height","13"));
  fontNode.addChild(NSXMLNode.elementWithName_stringValue("family","Arial"));
  var fontStyleNode = NSXMLNode.elementWithName("style");
  fontStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name","Regular"));
  fontStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("weight","400"));
  fontStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("italic","normal"));
  fontNode.addChild(fontStyleNode);
  return fontNode;
}

function createFontStyleNode(fontData){
  var fontNode = NSXMLNode.elementWithName("FontStyle");
  fontNode.addAttribute(NSXMLNode.attributeWithName_stringValue("size",fontData.size));
  fontNode.addAttribute(NSXMLNode.attributeWithName_stringValue("height",fontData.height));
  fontNode.addChild(NSXMLNode.elementWithName_stringValue("family",fontData.family));
  var fontStyleNode = NSXMLNode.elementWithName("style");
  fontStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("name",fontData.name));
  fontStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("weight",fontData.weight));
  fontStyleNode.addAttribute(NSXMLNode.attributeWithName_stringValue("italic",fontData.italic));
  fontNode.addChild(fontStyleNode);
  return fontNode;
}



function getJustinmindDeviceType(){
	if(selectedDeviceType=="Web"){
			return {'type':"web_1366",'orientation':selectedOrientation,'width':"1366",'height': "768",'isWeb':true,'isIphone':false,'isAndroid':false};
  }else if(selectedDeviceType=="iPhone 14 Pro Max"){
      return {'type':"iphone_14_promax",'orientation':selectedOrientation,'width':"430",'height': "932",'isWeb':false,'isIphone':true,'isAndroid':false};
  }else if(selectedDeviceType=="iPhone 14 Pro"){
      return {'type':"iphone_14_pro",'orientation':selectedOrientation,'width':"393",'height': "852",'isWeb':false,'isIphone':true,'isAndroid':false};
  }else if(selectedDeviceType=="iPhone 13 Pro Max"){
      return {'type':"iphone_13_promax",'orientation':selectedOrientation,'width':"428",'height': "926",'isWeb':false,'isIphone':true,'isAndroid':false};
  }else if(selectedDeviceType=="iPhone 13 Pro"){
      return {'type':"iphone_13_pro",'orientation':selectedOrientation,'width':"390",'height': "844",'isWeb':false,'isIphone':true,'isAndroid':false};
  }else if(selectedDeviceType=="iPhone 11 Pro Max"){
      return {'type':"iphone_11_promax",'orientation':selectedOrientation,'width':"414",'height': "896",'isWeb':false,'isIphone':true,'isAndroid':false};
  }else if(selectedDeviceType=="iPhone 11 Pro"){
      return {'type':"iphone_11_pro",'orientation':selectedOrientation,'width':"375",'height': "812",'isWeb':false,'isIphone':true,'isAndroid':false};
  }else if(selectedDeviceType=="Android Large"){
    return {'type':"android_large",'orientation':selectedOrientation,'width':"360",'height': "640",'isWeb':false,'isIphone':false,'isAndroid':true};
	}else if(selectedDeviceType=="Android Small"){
    return {'type':"android_small",'orientation':selectedOrientation,'width':"320",'height': "480",'isWeb':false,'isIphone':false,'isAndroid':true};
	}else if(selectedDeviceType=="iPad Pro 12.9"){
    return {'type':"ipad_pro_12",'orientation':selectedOrientation,'width':"1024",'height': "1366",'isWeb':false,'isIphone':true,'isAndroid':false};
	}else if(selectedDeviceType=="iPad Pro 11"){
    return {'type':"ipad_pro_11",'orientation':selectedOrientation,'width':"834",'height': "1194",'isWeb':false,'isIphone':true,'isAndroid':false};
	}else if(selectedDeviceType=="iPad Mini 8.3"){
    return {'type':"ipad_mini_8",'orientation':selectedOrientation,'width':"744",'height': "1133",'isWeb':false,'isIphone':true,'isAndroid':false};
	}else if(selectedDeviceType=="Android Tablet"){
		return {'type':"android_tablet",'orientation':selectedOrientation,'width':"768",'height': "1024",'isWeb':false,'isIphone':false,'isAndroid':true};
  }
	return {'type':"web_1366",'orientation':selectedOrientation,'width':"1024",'height': "768",'isWeb':true,'isIphone':false,'isAndroid':false};
}

function getAvailableLibraries(){
  var mapLibs = {};

  var basicLib = NSXMLNode.elementWithName("library");
  basicLib.addChild(NSXMLNode.elementWithName_stringValue("uuid","05ed0e22-75e0-459e-aa12-1e1c596d67c9"));
  basicLib.addChild(NSXMLNode.elementWithName_stringValue("name","Basic"));
  mapLibs["basic"] = basicLib;

  var webComponentsLib = NSXMLNode.elementWithName("library");
  webComponentsLib.addChild(NSXMLNode.elementWithName_stringValue("uuid","30ed0e22-75e0-459e-aa12-1e1c596d67a1"));
  webComponentsLib.addChild(NSXMLNode.elementWithName_stringValue("name","Web components"));
  mapLibs["webComponents"] = webComponentsLib;

  var iPhoneLib = NSXMLNode.elementWithName("library");
  iPhoneLib.addChild(NSXMLNode.elementWithName_stringValue("uuid","16ed0e22-75e0-459e-aa12-1e1c596d67c7"));
  iPhoneLib.addChild(NSXMLNode.elementWithName_stringValue("name","iPhone iOS"));
  mapLibs["iphone"] = iPhoneLib;

  var androidLib = NSXMLNode.elementWithName("library");
  androidLib.addChild(NSXMLNode.elementWithName_stringValue("uuid","26ed0e22-75e0-459e-aa12-1e1c596d67c8"));
  androidLib.addChild(NSXMLNode.elementWithName_stringValue("name","Android Phone"));
  mapLibs["android"] = androidLib;

  return mapLibs;
}


function createInvalidXMLCharacterSet(){
   var characterSet = NSMutableCharacterSet.characterSetWithRange(NSMakeRange(0x9, 1));
   characterSet.addCharactersInRange(NSMakeRange(0xA, 1));
   characterSet.addCharactersInRange(NSMakeRange(0xD, 1));
   characterSet.addCharactersInRange(NSMakeRange(0x20, 0xD7FF - 0x20));
   characterSet.addCharactersInRange(NSMakeRange(0xE000, 0xFFFD - 0xE000));
   characterSet.addCharactersInRange(NSMakeRange(0x10000, 0x10FFFF - 0x10000));
   invalidXMLCharacterSet = characterSet.invertedSet().retain();
}

function removeInvalidCharacters(textString){
  var text= NSString.alloc().initWithString(textString);
  var range = text.rangeOfCharacterFromSet(invalidXMLCharacterSet);
  if(range.length == 0)
    return text;
  var cleanedText = text.mutableCopy();
  while(range.length>0){
    cleanedText.deleteCharactersInRange(range);
    range = cleanedText.rangeOfCharacterFromSet(invalidXMLCharacterSet);
  }
  return cleanedText;
}

function calculateValidName(originalName){
  var name = originalName.replace(/ /g,"_");
  name = name.replace(/([^a-zA-Z0-9_-])/g,"");
  name = name.replace(/(^[^a-zA-Z]*)/,"");
  return getValidUniqueName(name);
}

function getValidUniqueName(originalName,calculatedName,calculatedIndex){
  if(!calculatedName){
    calculatedName = originalName;
  }

  if(mapID[calculatedName]){
    if(calculatedIndex){
      calculatedIndex++;
    }else{
      calculatedIndex = 1;
    }
    return getValidUniqueName(originalName,originalName+"_"+calculatedIndex,calculatedIndex);
  }
  mapID[calculatedName] = originalName;
  return calculatedName;
}


function getJustinmindRotation(rotation){
  var rote= parseInt(((rotation % 360)+360)%360);
  return rote;
}
