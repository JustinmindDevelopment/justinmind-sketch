var sketch = require('sketch/dom');


function getSelectedArtboards(sketchDoc){
  var artboards = [];
  if(!sketchDoc.selectedLayers.isEmpty){
    sketchDoc.selectedLayers.forEach(layer =>{
      if(isArtboard(layer.type))
        artboards.push(layer);
    });
  }
  return artboards;
}

function getAllArtboards(sketchDoc){
  var artboards = [];
  sketchDoc.pages.forEach(page =>{
    page.layers.forEach(layer =>{
      if(isArtboard(layer.type))
        artboards.push(layer);
    });
  });
  return artboards;
}

function getArtboardData(artboard){
  var items = [];
  if(exportArtboardAsSingleImage){
    if(artboard.layers.length>0){
      var itemData = getImageData(artboard);
      items.push(itemData);
    }
  }else{
    items  = getChildrenData(artboard);
  }
  if(cancelled)
    return {};
  translateToJIMGroups(items);

  return {
    'name': artboard.name,
    'id':  "id",
    'background': artboard.background.enabled ? getJIMColorFromHex(artboard.background.color) : null,
    'width': artboard.frame.width+"",
    'height': artboard.frame.height+"",
    'items': items
  };
}

function getChildrenData(container){
  var items  = [];

  var total = container.layers.length;
  for(var i=0;i<total;i++){

    var layer = container.layers[i];
    if(cancelled)
      return [];
    if(isMask(layer)){

      var imageMaskData = getImageMaskData(container,i);
      items.push(imageMaskData);
    }else if(!hasMask(layer)){
      var itemData = getItemData(layer);
      if(itemData){
        if(Array.isArray(itemData)){
          items = items.concat(itemData);
        }else
        items.push(itemData);
      }
    }
  });
  return items;
}

function getItemData(layer){
  if(isGroup(layer.type)){
    var groupData = getGroupData(layer);
    return groupData;
  }
  else if(isImage(layer.type))
    return getImageData(layer);
  else if(isShape(layer.type))
    return getShapeData(layer);
  else if(isText(layer.type))
    return getTextData(layer);
  else if(isSymbolInstance(layer.type)){
    try{
      var duplicate = layer.sketchObject.duplicate();
      var group = detachSymbol(duplicate);
      if(group!=null){
        var groupData = getItemData(group);
        if(groupData){
          if(layer.hidden)
            groupData.visible = false;
          group.sketchObject.removeFromParent();
          return groupData;
        }
      }
    }catch (error) {
    }
  }
  return;
}

function isMask(layer){
  return layer.sketchObject.hasClippingMask()==1;
}

function hasMask(layer){
  return layer.sketchObject.isMasked()==1;
}

function isSymbolMaster(layerType){
  return layerType==sketch.SymbolMaster.type;
}

function isSymbolInstance(layerType){
  return layerType==sketch.SymbolInstance.type;
}

function isText(layerType){
  return layerType==sketch.Text.type;
}

function isShape(layerType){
  return layerType==sketch.Shape.type || isShapePath(layerType);
}

function isShapePath(layerType){
  return layerType==sketch.ShapePath.type;
}

function isRectangle(shapeType, shape){
  return shapeType==sketch.ShapePath.ShapeType.Rectangle && shape.points.length==4;
}

function isOval(shapeType){
  return shapeType==sketch.ShapePath.ShapeType.Oval;
}

function isLine(shapeType, shape){
  return shapeType==sketch.ShapePath.ShapeType.Custom && shape.points.length==2 && shape.points[0].pointType==sketch.ShapePath.PointType.Straight && shape.points[1].pointType==sketch.ShapePath.PointType.Straight;
}

function isImage(layerType){
  return layerType==sketch.Image.type;
}

function isGroup(layerType){
  return layerType==sketch.Group.type;
}

function isArtboard(layerType){
  return layerType==sketch.Artboard.type;
}

function isTranslatableShape(shape){
    if(!isShapePath(shape.type)) return false;
    if(isAncestorMasked(shape)) return false;
    var style = shape.style;
    if(getNumEnabledLayerStyles(style.fills)>1) return false;
    if(getNumEnabledLayerStyles(style.shadows)>1) return false;
    if(getNumEnabledLayerStyles(style.borders)>1) return false;

    var fill = getSingleLayerStyle(style.fills);
    if(fill!=null && !(isTranslatableFill(fill))) return false;
    return true;
}

function isTranslatableFill(fill){
  if(fill.fillType==sketch.Style.FillType.Color)
    return true;
  if(fill.fillType==sketch.Style.FillType.Gradient && fill.gradient.gradientType==sketch.Style.GradientType.Linear)
    return true;
  if(fill.fillType==sketch.Style.FillType.Gradient && fill.gradient.gradientType==sketch.Style.GradientType.Radial && fill.gradient.aspectRatio>0.95 && fill.gradient.aspectRatio<1.05)
    return true;
  if(fill.fillType==sketch.Style.FillType.Pattern && fill.pattern.patternType!=sketch.Style.PatternFillType.Stretch)
    return true;
  return false;
}


//ANCESTORS & CONTAINERS

function isAncestorMasked(layer){
  var ancestors = layer.sketchObject.ancestors();
  for(var i=0;i<ancestors.length;i++){
    var ancestor = ancestors[i];
    if([ancestor isKindOfClass:[MSLayer class]]){
      if(ancestor.isMasked()==1){
          return true;
      }
    }
  }
  return false;
}


function detachSymbol(skSymbolInstance){
  var skVersion;
  try{
      skVersion = BCSketchInfo.shared().metadata().appVersion;
  }catch(e) {
      skVersion = MSApplicationMetadata.metadata().appVersion;
  }
  var skGroup;
  if(skVersion >=76)
     skGroup = skSymbolInstance.detachStylesAndReplaceWithGroup();
  else if(skVersion >=53)
     skGroup = skSymbolInstance.detachStylesAndReplaceWithGroupRecursively(false);
  else
    skGroup = skSymbolInstance.detachByReplacingWithGroup();

  return sketch.fromNative(skGroup);
    //var skSymbolMaster = skSymbolInstance.symbolMaster();
  //  if(skSymbolMaster.hasBackgroundColor() && skSymbolMaster.includeBackgroundColorInInstance()){
  //    var symbolBackgroundColor = skSymbolMaster.backgroundColor();
  //    var instanceFrame = skSymbolInstance.frame();

  //    var newBGLayer = MSShapePathLayer.shapeWithRect(NSMakeRect(0,0,instanceFrame.width(),instanceFrame.height()));
  //    var fill = newBGLayer.style().addStylePartOfType(0);//0==fill type
  //    fill.color = MSColor.colorWithRed_green_blue_alpha(symbolBackgroundColor.red(), symbolBackgroundColor.green(), symbolBackgroundColor.blue(), symbolBackgroundColor.alpha());
  //    if(group==null){
      //  var group = MSLayerGroup.new();
      //  group.setName(skSymbolInstance.name()+"_bg");

      //  group.frame().x  = instanceFrame.x();
      //  group.frame().y  = instanceFrame.y();
      //  skParent.addLayer(group);
    //  }
      //group.sketchObject.insertLayer_atIndex(newBGLayer,0);
      //newBGLayer.flatten();//without this line the SVG exported is empty (probably a sketch bug)
    //}
}


function toRadians(degrees){
  return degrees * (Math.PI/180);
}

function toDegrees(radians){
  return radians * (180/Math.PI);
}

function rotatePointAroundPoint(pointToRotate,center,angle){
  var x1 = pointToRotate.x - center.x;
  var y1 = pointToRotate.y - center.y;

  var x2 = (x1 * Math.cos(angle)) - (y1 * Math.sin(angle));
  var y2 = (x1 * Math.sin(angle)) + (y1 * Math.cos(angle));

  return {'x':Math.round(x2 + center.x),'y':Math.round(y2 + center.y)};
}

function getRotatedBBox(frame,angle){
  if(angle!=0){
    var rad = toRadians(angle);
    var center = {'x':Math.round(frame.x+(frame.width/2)),'y':Math.round(frame.y+(frame.height/2))};
    var topLeft = rotatePointAroundPoint({'x':frame.x,'y':frame.y},center,rad);
    var topRight = rotatePointAroundPoint({'x':frame.x+frame.width,'y':frame.y},center,rad);
    var bottomLeft = rotatePointAroundPoint({'x':frame.x,'y':frame.y+frame.height},center,rad);
    var bottomRight = rotatePointAroundPoint({'x':frame.x+frame.width,'y':frame.y+frame.height},center,rad);

    var minX = Math.min(Math.min(Math.min(topLeft.x,topRight.x),bottomLeft.x),bottomRight.x);
    var minY = Math.min(Math.min(Math.min(topLeft.y,topRight.y),bottomLeft.y),bottomRight.y);
    var maxX = Math.max(Math.max(Math.max(topLeft.x,topRight.x),bottomLeft.x),bottomRight.x);
    var maxY = Math.max(Math.max(Math.max(topLeft.y,topRight.y),bottomLeft.y),bottomRight.y);

    var w = maxX-minX;
    var h = maxY-minY;
    return {'x':minX,'y':minY,'width':w,'height':h};
  }
  return {'x':frame.x,'y':frame.y,'width':frame.width,'height':frame.height};
}

function getRotatedPos(position,framePos,frameSize,angle){
  if(angle!=0){
    var rad = toRadians(angle);
    var center = {'x':Math.round(framePos.x+(frameSize.width/2)),'y':Math.round(framePos.y+(frameSize.height/2))};
    var topLeft = rotatePointAroundPoint({'x':position.x,'y':position.y},center,rad);
    return {'x':topLeft.x,'y':topLeft.y};
  }
  return {'x':position.x,'y':position.y};
}

function calculateAbsolutePosition(layer){
  /*if(isSymbolMaster(layer.type) || isSymbolInstance(layer.type)){
    var absoluteRect = layer.absoluteRect();
    return {'x':absoluteRect.x(),'y':absoluteRect.y()};
  }
  //!!!!!!!! isTranslatableShape changed a lot!
  if( (isText(layer.type) && !enableExportTextAsImage) || isTranslatableShape(layer)){
    var absoluteRect = layer.absoluteRect();
    var angle = layer.rotation();
    var absolutePos = {'x':absoluteRect.x(),'y':absoluteRect.y()};
    if(angle!=0){
      var rotatedBBox = getRotatedBBoxPosition(absoluteRect,layer.frame(), angle);
      absolutePos.x+= absoluteRect.x() - rotatedBBox.x;
      absolutePos.y+= absoluteRect.y() - rotatedBBox.y;
    }
    return absolutePos;
  }
  var ancestry = layer.ancestry();
  var rect = MSSliceTrimming.trimmedRectForLayerAncestry(ancestry);
  return {'x':rect.origin.x,'y':rect.origin.y};*/
  return {'x':0,'y':0};
}

function getJIMColorFromNSColor(nsColor){
  return getJIMColor(nsColor.red(),nsColor.green(),nsColor.blue());
}

function getJIMColorFromMSImmutableColor(msImmutableColor){
  return getJIMColor(msImmutableColor.red(),msImmutableColor.green(),msImmutableColor.blue());
}

function getJIMColorFromUIColor(uiColor){
  if(uiColor){
    uiColor = uiColor.colorUsingColorSpaceName(NSCalibratedRGBColorSpace);
    var red = MOPointer.alloc().init();
    var green = MOPointer.alloc().init();
    var blue = MOPointer.alloc().init();
    var alpha = MOPointer.alloc().init();
    uiColor.getRed_green_blue_alpha(red,green,blue,alpha);
    return getJIMColor(red.value(),green.value(),blue.value());
  }
  return "0r0g0b";
}

//#000000ff
function getJIMColorFromHex(hexColor) {
  var result = hexColor.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/i);
  return result ? parseInt(result[1], 16)+"r"+ parseInt(result[2], 16)+"g"+parseInt(result[3], 16)+"b"+Math.round((1-parseInt(result[4],16)/255)*100)+"a": "0r0g0b";
}


function getJIMColor(red,green,blue){
  return parseInt(red*255)+"r"+parseInt(green*255)+"g"+parseInt(blue*255)+"b";
}

function getJIMTextAlignment(align){
  if(align==sketch.Text.Alignment.right)
    return "right";
  else if(align==sketch.Text.Alignment.center)
    return "center";
  return "left";
}

function getFontDataFromNSFont(nsFont){
  if(nsFont== null)
    nsFont = [NSFont systemFontOfSize:10];
  var dpiRatio = getScreenDPIRatio();
  var nsFontDescriptor = nsFont.fontDescriptor();
  var fontFamily = [nsFontDescriptor objectForKey:NSFont​Family​Attribute];
  var fontName = [nsFontDescriptor objectForKey:NSFont​Face​Attribute];
  var fontSize =  (nsFont.pointSize()*dpiRatio).toFixed(1);
  var fontTraits = [nsFontDescriptor objectForKey:NSFont​Traits​Attribute];
  var symbolicTrait =  [fontTraits objectForKey:NSFont​Symbolic​Trait];
  var isItalic = (symbolicTrait & NSItalicFontMask)!=0;
  var nsWeight =  NSFontManager.sharedFontManager().weightOfFont(nsFont);
  var jimWeight = getJIMFontWeight(nsWeight);

  return {
    'family':fontFamily,
    'size':fontSize+"",
    'height':"15",
    'name':fontName,
    'weight':jimWeight,
    'italic':isItalic ? "italic": "normal"
  };
}

function getFontDataFromStyle(style,nsFont){
  var dpiRatio = getScreenDPIRatio();
  var fontFamily = style.fontFamily;
  var nsFontDescriptor = nsFont.fontDescriptor();
  var fontName = [nsFontDescriptor objectForKey:NSFont​Face​Attribute];
  var fontSize =  (style.fontSize*dpiRatio).toFixed(1);
  var isItalic = style.fontStyle != undefined;
  var jimWeight = getJIMFontWeight(style.fontWeight);

  return {
    'family':fontFamily,
    'size':fontSize+"",
    'height':"15",
    'name':fontName,
    'weight':jimWeight,
    'italic':isItalic ? "italic": "normal"
  };
}

function getJIMFontWeight(osWeight){
  var weight = "400";
  switch (osWeight) {
    case 1:
    case 2:
    weight = "100";
    break;
    case 3:
    weight = "200";
    break;
    case 4:
    weight = "300";
    break;
    case 5:
    weight = "400";
    break;
    case 6:
    weight = "500";
    break;
    case 7:
    case 8:
    weight = "600";
    break;
    case 9:
    weight = "700";
    break;
    case 10:
    case 11:
    weight = "800";
    break;
    case 12:
    case 13:
    case 14:
    weight = "900";
    break;
  }
  return weight;
}
function getJIMTextDecoration(isUnderline,isLineThrough){
  if(isUnderline)
    return "underline";
  if(isLineThrough)
    return "line-through";
  return "none";
}

function getJIMLineHeight(lineHeight){
  if(lineHeight==null)
    return "0";
  return Math.round(lineHeight)+"";
}

function getScreenDPIRatio(){
  var primaryScreen = NSScreen.screens().objectAtIndex(0);
  var deviceDescription = primaryScreen.deviceDescription();
  var nsSize = [deviceDescription objectForKey:NSDeviceResolution];
  var screenDPI  =  nsSize.sizeValue().height;
  var isRetina = primaryScreen.backingScaleFactor()==2;
  if(isRetina)
  screenDPI = parseInt(screenDPI / 2);
  return screenDPI/96*0.9714;
}

function getJIMTransparency(opacity){
  var transparency = 1 - opacity;
  return parseInt(transparency * 100);
}

function getJIMRotation(rotation){
  //return parseInt(((-rotation % 360)+360)%360);
  return rotation;
}

function getNumEnabledLayerStyles(layerStyles){
  //layerStyle can be Border/Fill/Shadow
  var numEnabled = 0;
  layerStyles.forEach(layerStyle =>{
    if(layerStyle.enabled)
      numEnabled++;
  });
  return numEnabled;
}

function getSingleLayerStyle(layerStyles){
  //layerStyle can be Border/Fill/Shadow
  var singleStyle = null;
  layerStyles.some(layerStyle =>{
    if(layerStyle.enabled){
      singleStyle = layerStyle;
      return true;
    }
    return false;
  });
  return singleStyle;
}

function getJIMShadow(shadows){
  var shadow = getSingleLayerStyle(shadows);
  if(shadow!=null){
    var angle = 90;
    var dx = shadow.x;
    var dy = shadow.y;
    if(dx!=0 && dy!=0){
      angle = Math.round(toDegrees(Math.atan(-dy/dx)));
      if(dx>=0)
        angle= angle+180;
      angle = parseInt(((angle % 360)+360)%360);
    }
    return {
      'color':getJIMColorFromHex(shadow.color),
      'blur':shadow.blur+"",
      'distance': Math.round(Math.sqrt(Math.pow(dx,2)+Math.pow(dy,2)))+"",
      'dist': shadow.spread+"",
      'angle': angle+""
    };
  }
  return null;
}

function getJIMBorder(borders,borderOptions){
  var border = getSingleLayerStyle(borders);
  if(border!=null){
    return {
      'color':getJIMColorFromHex(border.color),
      'width':Math.round(border.thickness),
      'position':border.position==sketch.Style.BorderPosition.Center ? "center" :(border.position==sketch.Style.BorderPosition.Inside ? "inside" : "outside"),
      'style':borderOptions.dashPattern.length==1 ? ((Math.round(borderOptions.dashPattern[0])<=Math.round(border.thickness))?"dotted":"dashed"):"solid"
    };
  }
  return null;
}

function getJIMCornerRadius(topLeft,topRight,bottomRight,bottomLeft){
  //Math.round(Math.min(100,100*imageData.radius*2/Math.min(imageData.size.width,imageData.size.height)))
  if(topLeft==topRight && topLeft==bottomRight && topLeft==bottomLeft){
    return {'all':topLeft+""};
  }
  return {
    'tl':topLeft+"",
    'tr':topRight+"",
    'br':bottomRight+"",
    'bl':bottomLeft+""
  };
}

function getJIMBackground(fills){
  var fill = getSingleLayerStyle(fills);
  if(fill!=null){
    if(fill.fillType==sketch.Style.FillType.Color){//Double check, this method shouldn't be called if fillType isn't color (first check on isTranslatableShape)
      return {
        'type':"color",
        'color':getJIMColorFromHex(fill.color)
      };
    }else if(fill.fillType==sketch.Style.FillType.Gradient){
      var stops = [];
      fill.gradient.stops.forEach(stop=>{
        var jimStop = {
          'color':getJIMColorFromHex(stop.color),
          'position': stop.position
        };
        stops.push(jimStop);
      });
      var a = Math.abs(fill.gradient.from.x-fill.gradient.to.x);
      var b = Math.abs(fill.gradient.from.y-fill.gradient.to.y);
      var lineLength = Math.sqrt(a*a+b*b);
      return {
        'type': (fill.gradient.gradientType==sketch.Style.GradientType.Linear) ? "linear":"radial",
        'from': {'x': fill.gradient.from.x,'y': fill.gradient.from.y},
        'to': {'x': fill.gradient.to.x,'y': fill.gradient.to.y},
        'radius': lineLength,
        'stops': stops
      }
    }else if(fill.fillType==sketch.Style.FillType.Pattern){
      var type = "REPEAT";
      if(fill.pattern.patternType==sketch.Style.PatternFillType.Fit)
        type = "CONTAIN";
      else if(fill.pattern.patternType==sketch.Style.PatternFillType.Fill)
        type = "STRETCH";
      else if(fill.pattern.patternType==sketch.Style.PatternFillType.Stretch)
        type = "NO-REPEAT";

      var nsImage = fill.pattern.image.nsimage;
      var exportFolder = getExportImageFolder();

      if(!NSFileManager.defaultManager().fileExistsAtPath(exportFolder))){
        var directoryURL = NSURL.fileURLWithPath_isDirectory(exportFolder,true);
        NSFileManager.defaultManager().createDirectoryAtURL_withIntermediateDirectories_attributes_error(directoryURL,true,null,null);
      }
      var fileName =  NSString.stringWithUUID()+".png";
      var filePath = exportFolder+ fileName;
      var url = [NSURL  fileURLWithPath:filePath];
      var text= NSString.alloc().initWithString(filePath);
      var imageData = [nsImage TIFFRepresentation];
      var imageRep = [NSBitmapImageRep imageRepWithData:imageData];
      var imageProps = [NSDictionary dictionaryWithObject:[NSNumber numberWithFloat:1.0] forKey:NSImageCompressionFactor];
      imageData = [imageRep representationUsingType:NSPNGFileType properties:imageProps];
      [imageData writeToFile:text atomically:false];

      return {
        'type': "image",
        'image':{
          'filename': fileName,
          'type': type
        }
      }
    }
  }
  return null;
}

function getJIMDimension(frame,border){
  var bordersSize = 0;
  if(border!=null){
    if(border.position=="center")
      bordersSize = border.width;
    else if(border.position=="inside")
      bordersSize = 2*border.width;
  }
  return {
    'width':frame.width-bordersSize,
    'height':frame.height-bordersSize
  };
}

function getJIMDimensionForImageLayer(frame,border){
  var bordersSize = 0;
  if(border!=null){
    if(border.position=="center")
      bordersSize = border.width;
    else if(border.position=="outside")
      bordersSize = 2*border.width;
  }
  return {
    'width':frame.width+bordersSize,
    'height':frame.height+bordersSize
  };
}

function getJIMPosition(frame,border){
  var bordersSize = 0;
  if(border!=null){
    if(border.position=="center")
      bordersSize = border.width/2;
    else if(border.position=="outside")
      bordersSize = border.width;
  }
  return {
    'x':frame.x-bordersSize,
    'y':frame.y-bordersSize
  };
}

function getTextRanges(nsAttributedString, rangeToProcess, fillColor){
  var ranges  = [];
  var pointer = MOPointer.alloc().init();
  var dictionary = nsAttributedString.attributesAtIndex_longestEffectiveRange_inRange(rangeToProcess.location,pointer,rangeToProcess);
  var newRange = pointer.value();

  var nextRangeStart = newRange.location+newRange.length;
  var foregroundColor = dictionary[NSForeground​Color​Attribute​Name];

  if(foregroundColor==null){
    foregroundColor = dictionary["MSAttributedStringColorAttribute"];
    if(foregroundColor!=null)
      foregroundColor = getJIMColorFromMSImmutableColor(foregroundColor);
  }else{
    foregroundColor = getJIMColorFromUIColor(foregroundColor);
  }
  if(foregroundColor==null){
      if(fillColor == null)
        foregroundColor = getJIMColor(0.0,0.0,0.0);
      else
        foregroundColor = getJIMColorFromHex(fillColor);
  }

  var font = dictionary[NSFontAttributeName];
  var underline = dictionary[NSUnderlineStyleAttributeName];
  var linethrough = dictionary[NSStrikethroughStyleAttributeName];
  var decoration = getJIMTextDecoration(underline && underline!=0,linethrough && linethrough!=0);
  var kerning = dictionary[NSKernAttributeName];
  if(kerning==null)
    kerning = 0;
  var rangeData = {
    'start':newRange.location,
    'end':nextRangeStart,
    'fontData': getFontDataFromNSFont(font),
    'text_color':foregroundColor,
    'text_decoration': decoration,
    'kerning':kerning.toString()
  };
  ranges.push(rangeData);
  if(nextRangeStart<nsAttributedString.string().length()){
    var nextRangeToProcess = NSMakeRange(nextRangeStart,nsAttributedString.string().length()-nextRangeStart);
    var nextRanges = getTextRanges(nsAttributedString,nextRangeToProcess,fillColor);
    ranges = ranges.concat(nextRanges);
  }

  return ranges;
}


function getTextData(text){
  if(enableExportTextAsImage)
    return getImageData(text);
  var style = text.style;
  var fontColor = style.textColor;
  var fillColor = null;
  var fills = text.style.fills;
  style.fills.some((fill,index)=>{
    if(fill.fillType==sketch.Style.FillType.Color && fill.enabled){
      fillColor = fill.color;
      return true;
    }
    return false;
  });

  var textValue = text.text;
  var nsFont = text.sketchObject.font();
  var nsAttributedString = text.sketchObject.attributedStringValue();
  var ranges;
  if(nsAttributedString.string().length()>0){
    var fullRange =  NSMakeRange(0,nsAttributedString.string().length());
    ranges = getTextRanges(nsAttributedString,fullRange,fillColor);
  }
  else{
    ranges = [];
    var rangeData = {
        'start':0,
        'end':0,
        'fontData': getFontDataFromStyle(style,nsFont),
        'text_color':getJIMColorFromHex(fontColor),
        'text_decoration': "none",
        'kerning':0
    };
    ranges.push(rangeData);
  }
  var transformOption = style.textTransform;
  if(transformOption=="uppercase")
    textValue= textValue.toUpperCase();
  else if(transformOption=="lowercase")
    textValue= textValue.toLowerCase();

  return {
    'objectID':text.id,
    'type':"text",
    'name':text.name,
    'size':{'width':text.frame.width,'height':text.frame.height},
    'absolutePosition':calculateAbsolutePosition(text),
    'relativePosition':{'x':text.frame.x,'y':text.frame.y},
    'text':textValue,
    'fontData': getFontDataFromStyle(style,nsFont),
    'text_color':getJIMColorFromHex(fontColor),
    'text_decoration':"none",
    'text_hAlign':getJIMTextAlignment(style.alignment),
    'line_height':getJIMLineHeight(style.lineHeight),
    'transparency': getJIMTransparency(style.opacity),
    'rotation': getJIMRotation(text.transform.rotation),
    'visible':!text.hidden,
    'textShadow': getJIMShadow(style.shadows),
    'ranges': ranges
  };
}

function getShapeData(shape){
  if(!isTranslatableShape(shape))
    return getSVGLayerData(shape);
  if(isRectangle(shape.shapeType,shape))
    return getRectangleData(shape);
  if(isOval(shape.shapeType))
    return getEllipseData(shape);
  if(isLine(shape.shapeType, shape))
    return getLineData(shape);
  return getSVGLayerData(shape);
}


function getLineData(shape)
{
    var style = shape.style;

    var a = shape.frame.width*Math.abs(shape.points[0].point.x-shape.points[1].point.x);
    var b = shape.frame.height*Math.abs(shape.points[0].point.y-shape.points[1].point.y);

    var lineLength = Math.sqrt(a*a+b*b);
    var delta;
    if(shape.transform.rotation>0)
      delta = getRotatedPos(shape.frame,shape.frame,shape.frame,-shape.transform.rotation);
    else
      delta = getRotatedPos(shape.frame,shape.frame,shape.frame,shape.transform.rotation);

    return {
      'objectID':shape.id,
      'type':"line",
      'name':shape.name,
      'size':{'width':a,'height':b},
      'lineLength':lineLength,
      'relativePosition':{'x':delta.x,'y':delta.y},
      'visible':!shape.hidden,
      'rotation':getJIMRotation(shape.transform.rotation),
      'transparency':getJIMTransparency(style.opacity),
      'shadow':getJIMShadow(style.shadows),
      'border':getJIMBorder(style.borders,style.borderOptions)
    };
}

function getRectangleData(shape)
{
    var style = shape.style;
    var border = getJIMBorder(style.borders,style.borderOptions);

    return {
      'objectID':shape.id,
      'type':shape.name.startsWith("in_") ?"inputText":"rectangle",
      'name':shape.name,
      'size':getJIMDimension(shape.frame,border),
      'relativePosition':getJIMPosition(shape.frame,border),
      'visible':!shape.hidden,
      'rotation':getJIMRotation(shape.transform.rotation),
      'transparency':getJIMTransparency(style.opacity),
      'shadow':getJIMShadow(style.shadows),
      'border':border,
      'background':getJIMBackground(style.fills),
      'radius':getJIMCornerRadius(shape.points[0].cornerRadius,shape.points[1].cornerRadius,shape.points[2].cornerRadius,shape.points[3].cornerRadius)
    };
}


function getEllipseData(shape)
{
    var style = shape.style;
    var border = getJIMBorder(style.borders,style.borderOptions);
    return {
      'objectID':shape.id,
      'type':"ellipse",
      'name':shape.name,
      'size':getJIMDimension(shape.frame,border),
      'relativePosition':getJIMPosition(shape.frame,border),
      'visible':!shape.hidden,
      'rotation':getJIMRotation(shape.transform.rotation),
      'transparency':getJIMTransparency(style.opacity),
      'shadow':getJIMShadow(style.shadows),
      'border':border,
      'background':getJIMBackground(style.fills)
    };
}

function getImageData(image){
  var pngInfo = exportLayerAsPNG(image);
  //var trimmedBounds = calculateImageTrimmedBounds(image.sketchObject);
  var style = image.style;
  var border = getJIMBorder(style.borders,style.borderOptions);
  var pos = getRotatedBBox(image.frame,image.transform.rotation);
  return {
    'objectID':image.id,
    'type':"image",
    'name':image.name,
    //'size':trimmedBounds,//getJIMDimensionForImageLayer(image.frame,border),
    //'relativePosition':trimmedBounds,
    'relativePosition':{'x':image.frame.x,'y':image.frame.y},
    'size':{'width':pngInfo.size.width,'height':pngInfo.size.height},
    'rotation':0,
    'filename':pngInfo.fileName,
    'visible':!image.hidden
  };
}


function getSVGLayerData(layer){
  if(layer.sketchObject.isMasked()==1 || isAncestorMasked(layer))
    return getImageData(layer);
  var svgInfo = exportLayerAsSVG(layer);
  //var trimmedBounds = calculateImageTrimmedBounds(layer.sketchObject);
  var style = layer.style;
  var border = getJIMBorder(style.borders,style.borderOptions);
  var pos = getRotatedBBox(layer.frame,layer.transform.rotation);

  return {
    'objectID':layer.id,
    'type':"svg",
    'name':layer.name,
    //'size':trimmedBounds,//getJIMDimensionForImageLayer(image.frame,border),
    //'relativePosition':trimmedBounds,
    'relativePosition':{'x':layer.frame.x,'y':layer.frame.y},
    'size':{'width':svgInfo.size.width,'height':svgInfo.size.height},
    'rotation':0,
    'filename':svgInfo.fileName,
    'visible':!layer.hidden
  };
}

function getGroupData(group){
  if(isLayerMarkedAsSVG(group))
    return getSVGLayerData(group);

  var items  = getChildrenData(group);
  if(items.length==0)
    return null;

  return {
      'objectID':group.id,
      'type':"group",
      'name':group.name,
      'relativePosition':{'x':group.frame.x,'y':group.frame.y},
      'size':{'width':group.frame.width,'height':group.frame.height},
      'items':items,
      'visible':!group.hidden,
      'rotation':group.transform.rotation
  };
}

function getImageMaskData(parent,indexMask){
  var maskLayer = parent.layers[indexMask];
  var svgInfo = exportMaskedLayersAsSVG(parent,indexMask);
  //var trimmedBounds = calculateImageTrimmedBounds(image.sketchObject);
  /*var style = image.style;
  var border = getJIMBorder(style.borders,style.borderOptions);
  var pos = getRotatedBBox(image.frame,image.transform.rotation);*/

  return {
    'objectID':maskLayer.id,
    'type':"svg",
    'name':maskLayer.name,
    //'size':trimmedBounds,//getJIMDimensionForImageLayer(image.frame,border),
    //'relativePosition':trimmedBounds,
    'relativePosition':{'x':svgInfo.pos.x,'y':svgInfo.pos.y},
    'size':{'width':svgInfo.size.width,'height':svgInfo.size.height},
    'rotation':0,
    'filename':svgInfo.fileName,
    'visible':!maskLayer.hidden
  };
}

/*
function calculateImageTrimmedBounds(skLayer){
  const SliceTrimmingClass = NSClassFromString("SketchRendering.MSSliceTrimming") ?? NSClassFromString("MSSliceTrimming");
  var ancestry = skLayer.ancestry();
  let dirty = SliceTrimmingClass.trimmedRectForLayerAncestry(ancestry);
  dirty.origin.x-=  currentArtboard.frame.x;
  dirty.origin.y-=  currentArtboard.frame.y;
//  alert("a",dirty.origin);
  let request = MSExportRequest.exportRequestsFromLayerAncestry_(ancestry).firstObject();
  request.setShouldTrim(false);
  let exporter = MSExporter.exporterForRequest_colorSpace_(request, nil);
  let trimmedSize = exporter.trimmedBounds().size;
  let trimmedOriginOffset = exporter.trimmedBounds().origin;
  let unalignedResult = NSMakeRect(dirty.origin.x+trimmedOriginOffset.x,
                                 dirty.origin.y+trimmedOriginOffset.y,
                                 trimmedSize.width, trimmedSize.height);

  var ancestors = skLayer.ancestors();
  var parent = sketch.fromNative(ancestors[ancestors.length-1]);
  var parentFrame = sketch.fromNative(parent).frame;
  var frame = NSIntegralRectWithOptions(unalignedResult, NSAlignAllEdgesOutward);

  // (Optional step) The calculated rectangle might not be pixel-aligned by default
  // (i.e. there could be non-integral coordinates or size values like 0.5 or 1.89,
  // and bitmap renditions can only start/end on a full pixel)
  var kk = {
    "x":frame.origin.x - parentFrame.x,
    "y":frame.origin.y - parentFrame.y,
    "width":frame.size.width,
    "height":frame.size.height
  };

  return kk;
}*/

function translateToJIMGroups(items,parentGroup){
  items.forEach(item=>{
      if(parentGroup!=null){
        if(parentGroup.rotation==0){
          item.relativePosition.x+=parentGroup.relativePosition.x;
          item.relativePosition.y+=parentGroup.relativePosition.y;
        }else {
          item.relativePosition.x+=parentGroup.relativePosition.x;
          item.relativePosition.y+=parentGroup.relativePosition.y;

          if(item.type!="image" && item.type!="svg") {
            var itemCenter = {'x':item.relativePosition.x+(item.size.width/2),'y':item.relativePosition.y+(item.size.height/2)};
            var delta = getRotatedPos(itemCenter,parentGroup.relativePosition,parentGroup.size,parentGroup.rotation);
            item.relativePosition.x=delta.x-(item.size.width/2);
            item.relativePosition.y=delta.y-(item.size.height/2);
            item.rotation+=parentGroup.rotation;
          }

        }
        if(!parentGroup.visible)
          item.visible = false;
      }
      if(item.type=="group")
        translateToJIMGroups(item.items,item);
  });

}

function isLayerMarkedAsSVG(layer){
  return enableExportGroupAsSingleLayer && layer.name.startsWith("ic_");
}

function getSketchVersion(){
  var skVersion;
  try{
      skVersion = BCSketchInfo.shared().metadata().appVersion;
  }catch(e) {
      skVersion = MSApplicationMetadata.metadata().appVersion;
  }
  return skVersion;
}
