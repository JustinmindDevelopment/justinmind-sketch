@import 'utils.js'
@import 'MochaJSDelegate.js'


function openExportDialog(titleText,subtitleText,showTextAsImageOption){
  var app = [NSApplication sharedApplication];
  var exportWindow = [[NSWindow alloc] init];
  var horizontalMargin = 35;
  var width = 640;
  var height = 510;
  var blackTextAttribs =  {};
  var isDarkMode = isDarkModeEnabled();

  COScript.currentCOScript().setShouldKeepAround_(true);
  [exportWindow setFrame:NSMakeRect(0, 0, width, height+20) display: false];
  if(isDarkMode)
    [[exportWindow contentView] setBackgroundColor:NSColor.colorWithRed_green_blue_alpha(35/255, 31/255, 41/255, 1.0)];
  else
    [[exportWindow contentView] setBackgroundColor:NSColor.whiteColor()];

  var contentView = [exportWindow contentView];
  contentView.setWantsLayer(true);

  var headerSize = 116;
  var headerView = [[NSView alloc] initWithFrame:NSMakeRect(0, height-headerSize, width, headerSize)];
  [[exportWindow contentView] addSubview:headerView];


  var imageView = [[NSImageView alloc] initWithFrame: NSMakeRect(10, 44, 220, 39)];

  var file =  isDarkMode ? '../Resources/logo_white.png' : '../Resources/logo.png';
  resolve = require('path').resolve;
  var icon = NSImage.alloc().initByReferencingFile(resolve(file));
  [imageView setImage: icon];
  [headerView addSubview:imageView];
  var fontManager = [NSFontManager sharedFontManager];

  var subtitleField = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 2, 550, 25)];
  [subtitleField setEditable:false];
  [subtitleField setBordered:false];
  var subtitleFont =[fontManager fontWithFamily:"Helvetica" traits:0 weight:0 size:13];
  [subtitleField setFont:subtitleFont];
  [subtitleField setDrawsBackground:false];
  [subtitleField setStringValue:subtitleText];
  var subtitleWidth = subtitleField.fittingSize().width;
  subtitleField.frame = NSMakeRect(22, 2,subtitleWidth, 25);
  [headerView addSubview:subtitleField];

  var inputFont =[fontManager fontWithFamily:"Helvetica" traits:0 weight:0 size:12];

  var deviceTypeCombo = [[NSPopUpButton alloc] initWithFrame: NSMakeRect(22, 360, 190, 25)];
  deviceTypeCombo.addItemsWithTitles(deviceTypes);
  var itemArray = [deviceTypeCombo itemArray];
  for (var i = 0; i < [itemArray count]; i++) {
    var item = [itemArray objectAtIndex:i];
    [item setAttributedTitle:NSAttributedString.attributedStringWithString_attributes_([item title],blackTextAttribs)];
  }
  [deviceTypeCombo setFont:inputFont];
  [deviceTypeCombo selectItemAtIndex:0];
  [deviceTypeCombo setEnabled:false];
  [[exportWindow contentView] addSubview:deviceTypeCombo];

  var portraitButton =[[NSButton alloc] initWithFrame: NSMakeRect(230, 361, 160, 25)];
  [portraitButton setFont:inputFont];
  [portraitButton setButtonType:NSRadioButton];
  [portraitButton setTitle:orientation[0]];
  [portraitButton setAction:"orientationAction:"];
  [portraitButton setEnabled:false];
  [[exportWindow contentView] addSubview:portraitButton];

  var landscapeButton =[[NSButton alloc] initWithFrame: NSMakeRect(310, 361, 160, 25)];
  [landscapeButton setFont:inputFont];
  [landscapeButton setButtonType:NSRadioButton];
  [landscapeButton setTitle:orientation[1]];
  [landscapeButton setAction:"orientationAction:"];
  [landscapeButton setEnabled:false];
  [[exportWindow contentView] addSubview:landscapeButton];

  var defaultDevice = getDefault("exportDevice",null);
  if(defaultDevice){
    var indexDevice = deviceTypes.indexOf(defaultDevice.trim());
    if(indexDevice>=0){
      [deviceTypeCombo selectItemAtIndex:indexDevice];
    }
  }
  [portraitButton setState: NSOnState];
  var defaultOrientation = getDefault("exportOrientation",null);
  if(defaultOrientation){
    var indexOrientation = orientation.indexOf(defaultOrientation.trim());
    if(indexOrientation==1)
      [landscapeButton setState: NSOnState];
  }

  [deviceTypeCombo setCOSJSTargetFunction:function(sender) {
    var projectIndex = [deviceTypeCombo indexOfSelectedItem];
    [portraitButton setEnabled: projectIndex != 0];
    [landscapeButton setEnabled: projectIndex != 0];
  }];
  var artboards = artboardsToExport;
  var artboardsCount = artboardsToExport.length;

  var entryWidth = 92;
  var entryHeight = 104;
  var previewWidth = 76;
  var previewHeight = 76;

  var horizontalSpacing = 22;
  var verticalSpacing = 18;

  var columns = 5;
  var rows = Math.ceil(artboardsCount/columns);
  var marginWidth = 12;
  var marginHeight = 12;
  var containerHeight = Math.max(270,((rows*entryHeight)+((rows-1)*verticalSpacing))+(marginHeight*2));
  var artboardsContainer = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, (marginWidth*2)+(entryWidth * columns)+(horizontalSpacing*(columns-1)), containerHeight)];

  var scrollArtboards = [[NSScrollView alloc] initWithFrame:NSMakeRect(22, height-headerSize-270-48, 596, 270)];
  scrollArtboards.setWantsLayer(true);
  if(isDarkMode)
    [scrollArtboards setBackgroundColor:NSColor.colorWithRed_green_blue_alpha(19/255, 20/255, 21/255, 1.0)];
  else
    [scrollArtboards setBackgroundColor:NSColor.colorWithRed_green_blue_alpha(246/255, 247/255, 248/255, 1.0)];

  [scrollArtboards setCornerRadius:5];
  [scrollArtboards setHasVerticalScroller:true];
  [scrollArtboards setHasHorizontalScroller:true];
  [scrollArtboards setAutoresizingMask:NSViewWidthSizable|NSViewHeightSizable];
  [scrollArtboards setDocumentView:artboardsContainer];
  [scrollArtboards setDrawsBackground:true];
  [scrollArtboards setAutohidesScrollers:true];
  var scrollLayer = [scrollArtboards layer];
  [[scrollArtboards verticalScroller] setScrollerStyle:NSScrollerStyleLegacy];
  [[exportWindow contentView] addSubview:scrollArtboards];

  var mapArtboardViews = {};
  var mapPreviews = {};
  var mapCheckboxes = {};

  var entryFont =[fontManager fontWithFamily:"Helvetica" traits:0 weight:0 size:10];
  for (var i=0;i<artboardsCount;i++){
      var artboard= artboards[i];
      var name = artboard.name;

      var r = i % columns;
      var x = r * (entryWidth+horizontalSpacing)+marginWidth;
      var y = containerHeight - marginHeight - (entryHeight) - (Math.floor(i/columns)*(entryHeight+verticalSpacing));
      var artboardView = [[NSView alloc] initWithFrame:NSMakeRect(x,y, entryWidth,entryHeight)];
      [artboardView setHidden:true];
      [artboardsContainer addSubview:artboardView];

      var previewBgView = [[NSView alloc] initWithFrame:NSMakeRect(0,18, entryWidth,entryHeight-18)];
      if(isDarkMode)
        [previewBgView setBackgroundColor:NSColor.colorWithRed_green_blue_alpha(90/255, 87/255, 95/255, 1.0)];
      else
        [previewBgView setBackgroundColor:NSColor.colorWithRed_green_blue_alpha(236/255, 239/255, 241/255, 1.0)];
      [previewBgView setCornerRadius:3];
      [previewBgView setToolTip:name];
      [artboardView addSubview:previewBgView];

      var artboardPreview = [[NSImageView alloc] initWithFrame: NSMakeRect(8,4, previewWidth, previewHeight)];
      [artboardView addSubview:artboardPreview];
      artboardPreview.setWantsLayer(true);
      [[artboardPreview layer] setShadowOpacity:0.5];
      [previewBgView addSubview:artboardPreview];

      var artboardName =[[NSTextField alloc] initWithFrame: NSMakeRect(0, 2,69, 12)];

      [artboardName setEditable:false];
      [artboardName setBordered:false];
      [artboardName setFont:entryFont];
      [artboardName setDrawsBackground:false];
      [artboardName setStringValue:name];
      [artboardName setToolTip:name];
      var nameWidth = artboardName.fittingSize().width;
      var nameX = (entryWidth-17 - nameWidth)/2;
      if(nameWidth>(entryWidth-17)){
        nameWidth = 72;
        nameX = 0;
      }else if(nameWidth>(entryWidth - (17*2)))
        nameX =  entryWidth - nameWidth - 17;
      artboardName.frame = NSMakeRect(nameX, 2,nameWidth, 12);

      [[artboardName cell] setLineBreakMode:NSLineBreakByTruncatingTail];
      [artboardView addSubview:artboardName];

      artboardName.alignment = NSTextAlignmentCenter;

      var artboardCheck = [[NSButton alloc] initWithFrame: NSMakeRect(74,0, 16, 16)];
      [artboardCheck setButtonType:NSSwitchButton];
      [artboardCheck setTitle:@""];

      var contains = selectedArtboards.length==0 ? true :(selectedArtboards.indexOf(artboard.sketchObject)!=-1);
      [artboardCheck setState: (contains ? NSOnState : NSOffState)];

      [artboardCheck setEnabled:false];
      [artboardView addSubview:artboardCheck];

      mapArtboardViews[i] = artboardView;
      mapPreviews[i] = artboardPreview;
      mapCheckboxes[i] = artboardCheck;
  }
  [[scrollArtboards contentView] scrollToPoint:NSMakePoint(0, NSMaxY([[scrollArtboards documentView] frame]) - [[scrollArtboards contentView] bounds].size.height)];
  [scrollArtboards reflectScrolledClipView: [scrollArtboards contentView]];

  var exportAll =[[NSButton alloc] initWithFrame: NSMakeRect(22, 46, 160, 20)];
  [exportAll setFont:inputFont];
  [exportAll setButtonType:NSSwitchButton];
  [exportAll setTitle:@"Select all artboards"];


  var allselected = selectedArtboards.length==0 || selectedArtboards.length==artboardsCount;
  [exportAll setState:(allselected ? NSOnState : NSOffState)];
  [exportAll setEnabled:false];
  [[exportWindow contentView] addSubview:exportAll];
  [exportAll setCOSJSTargetFunction:function(sender) {
    for(var i=0;i<artboardsCount;i++){
      var artboardCheckbox = mapCheckboxes[i];
      [artboardCheckbox setState:[exportAll state]];
    }
  }];

  var exportButton = [[NSButton alloc] initWithFrame:NSMakeRect(533, 15, 92, 30)],
  cancelButton = [[NSButton alloc] initWithFrame:NSMakeRect(433, 15, 92, 30)];
  [exportButton setTitle:"Export"];
  [exportButton setBezelStyle:NSRoundedBezelStyle];
  [exportButton setAction:"callAction:"];
  [cancelButton setTitle:"Cancel"];
  [cancelButton setBezelStyle:NSRoundedBezelStyle];
  [cancelButton setAction:"callAction:"];
  [exportButton setEnabled: false];
  [cancelButton setEnabled: false];

  var bottomActionsView = [[NSView alloc] initWithFrame:NSMakeRect(0, 0,width, 68)];
  [[exportWindow contentView] addSubview:bottomActionsView];


  var loadingView = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, width, height-146)];
  loadingView.setWantsLayer(true);
  [[exportWindow contentView] addSubview:loadingView positioned:NSWindowAbove relativeTo:null];

  var activityIndicator = [[NSProgressIndicator alloc]initWithFrame:NSMakeRect(160,215,width-320,NSProgressIndicatorPreferredLargeThickness)];
  [activityIndicator setStyle:NSProgress​Indicator​Bar​Style];
  [activityIndicator setBezeled:true];
  [activityIndicator setMinValue:0];
  [activityIndicator setMaxValue:artboardsCount];
  [activityIndicator setDoubleValue:0];
  [activityIndicator setIndeterminate:false];
  [loadingView addSubview:activityIndicator];

  var processingLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(170, 190, 200, 20)];
  [processingLabel setAlignment:NSCenterTextAlignment];
  [processingLabel setEditable:false];
  [processingLabel setBordered:false];
  [processingLabel setDrawsBackground:false];
  [processingLabel setFont:[fontManager fontWithFamily:"Helvetica" traits:0 weight:0 size:11]];
  [processingLabel setStringValue:"Processing artboards"];
  [loadingView addSubview:processingLabel];

  [exportButton setCOSJSTargetFunction:function(sender) {
    artboardsToExport = [];
    for(var i=0;i<artboardsCount;i++){
      var artboardCheckbox = mapCheckboxes[i];
      if([artboardCheckbox state]==NSOnState){
        artboardsToExport.push(artboards[i]);
      }
    }
    if(artboardsToExport.length==0){
        alert("No artboard selected", "You must select at least one artboard");
      return;
    }

    selectedDeviceType = deviceTypes[[deviceTypeCombo indexOfSelectedItem]];
    var orientationOption = 0;
    if([landscapeButton state]==NSOnState)
      orientationOption = 1;
    selectedOrientation = orientation[orientationOption];
    setDefault("exportDevice",selectedDeviceType);
    setDefault("exportOrientation",selectedOrientation);
    /*if(showTextAsImageOption)
      setDefault("exportTextAsImage",enableExportTextAsImage);*/
    setDefault("export2x",true);
    setDefault("exportSingleLayer",enableExportGroupAsSingleLayer);
    [exportWindow orderOut:nil];
    [[app mainWindow] endSheet: exportWindow];
    [exportButton setCOSJSTargetFunction:undefined];
    [cancelButton setCOSJSTargetFunction:undefined];
    COScript.currentCOScript().setShouldKeepAround_(false);

    var jimFile = openSaveFileDialog();
    if(jimFile){
      openProgressDialog(jimFile);
    }
  }];

  [cancelButton setCOSJSTargetFunction:function(sender) {
    [exportWindow orderOut:nil];
    [[app mainWindow] endSheet: exportWindow];
    [exportButton setCOSJSTargetFunction:undefined];
    [cancelButton setCOSJSTargetFunction:undefined];
    COScript.currentCOScript().setShouldKeepAround_(false);
  }];
  [bottomActionsView addSubview:exportButton];
  [bottomActionsView addSubview:cancelButton];
  [exportWindow setDefaultButtonCell:[exportButton cell]];


  var index = 0;

  var  processor = new MochaJSDelegate({
    "processArtboard:":(function(timer) {
      try{
        var artboard=artboards[index];
        var wSkDoc = sketchDoc.sketchObject;
        var pngInfo = exportLayerAsPNG(artboard);
        var hasBackgroundColor = artboard.sketchObject.hasBackgroundColor();
        var fileFolder = getExportImageFolder();
        var filePath = getExportImageFolder()+pngInfo.fileName;
        var preview = NSImage.alloc().initByReferencingFile(filePath);
        var artboardPreview = mapPreviews[index];
        [artboardPreview setImage: preview];
        if(hasBackgroundColor==false)
          [artboardPreview setBackgroundColor:NSColor.whiteColor()];
        exportOptions.removeExportFormat(exportSize);
      }catch(e){
      }

      index += 1;
      [activityIndicator setDoubleValue:(index+1)];
      [[exportWindow contentView] addSubview:loadingView positioned:NSWindowAbove relativeTo:null];
      if (index >= artboardsCount) {
        timer.invalidate();
        [loadingView setHidden:true];
        [exportAll setEnabled:true];
        [deviceTypeCombo setEnabled:true];
        var indexDevice = [deviceTypeCombo indexOfSelectedItem];
        [portraitButton setEnabled: indexDevice != 0];
        [landscapeButton setEnabled: indexDevice != 0];
        [exportButton setEnabled: true];
        [cancelButton setEnabled: true];
        for(var i=0;i<artboardsCount;i++){
          var artboardView = mapArtboardViews[i];
          [artboardView setHidden:false];
          var artboardCheckbox = mapCheckboxes[i];
          [artboardCheckbox setEnabled:true];
        }
      }
    }),
  });


  var timer = [NSTimer scheduledTimerWithTimeInterval: 0.001 target: processor.getClassInstance() selector: "processArtboard:" userInfo: nil repeats: true]
  var runLoop = [NSRunLoop currentRunLoop];
  [runLoop addTimer:timer forMode:NSRunLoopCommonModes];
  [[app mainWindow] beginSheet:exportWindow completionHandler:nil];

}

function openSaveFileDialog(){
  removeFolderContents(tempFolder);
  var jimFilename = nsDoc.displayName()+ ".vp";

  var panel = [NSSavePanel savePanel];
  var allowedTypes = NSArray.arrayWithObject("vp");

  panel.setAllowedFileTypes(allowedTypes);
  panel.setExtensionHidden(false);
  panel.setNameFieldStringValue(jimFilename);
  //
  var result = panel.runModal();
  if (result == 0) {
    return null;
  }
  return panel.URL().path();
}

function openProgressDialog(jimFile){
  cancelled = false;
  COScript.currentCOScript().setShouldKeepAround_(true);
  var app = [NSApplication sharedApplication];
  var progressWindow = [[NSWindow alloc] init];
  var width = 455;
  [progressWindow setFrame:NSMakeRect(0, 0, width, 220) display: false];
  var contentView = [progressWindow contentView];

  var isDarkMode = isDarkModeEnabled();
  var imageView = [[NSImageView alloc] initWithFrame: NSMakeRect(101, 130, 250, 42)];
  var file =  isDarkMode ? '../Resources/logo_white.png' : '../Resources/logo.png';
  var icon = NSImage.alloc().initByReferencingFile(resolve(file));
  [imageView setImage: icon];
  [contentView addSubview:imageView];

  var titleField = [[NSTextField alloc] initWithFrame:NSMakeRect(50, 92, 355, 20)];
[titleField setAlignment:NSCenterTextAlignment];
[titleField setEditable:false];
[titleField setBordered:false];
[titleField setDrawsBackground:false];
[titleField setFont:[NSFont boldSystemFontOfSize:13]];
[titleField setStringValue:"Exporting artboards to Justinmind"];
var titleWidth = titleField.fittingSize().width;
titleField.frame = NSMakeRect((width-titleWidth)/2, 96,titleWidth, 20);
[contentView addSubview:titleField];

  var subtitleField = [[NSTextField alloc] initWithFrame:NSMakeRect(50, 42, 355, 25)];
  [subtitleField setAlignment:NSCenterTextAlignment];
  [subtitleField setEditable:false];
  [subtitleField setBordered:false];
  [subtitleField setFont:[NSFont systemFontOfSize:11]];
  [subtitleField setDrawsBackground:false];
  [subtitleField setStringValue:"Exporting artboards..."];
  var subtitleWidth = subtitleField.fittingSize().width;
  subtitleField.frame = NSMakeRect((width-subtitleWidth)/2, 42,subtitleWidth, 25);
  [contentView addSubview:subtitleField];

  var activityIndicator = [[NSProgressIndicator alloc]initWithFrame:NSMakeRect(75,68,305,20)];
  var progressCount = artboardsToExport.length+2;
  [activityIndicator setStyle:NSProgress​Indicator​Bar​Style];
  [activityIndicator setBezeled:true];
  [activityIndicator setMinValue:0];
  [activityIndicator setMaxValue:progressCount];
  [activityIndicator setDoubleValue:0];
  [activityIndicator setIndeterminate:false];
  [[progressWindow contentView] addSubview:activityIndicator];


  var cancelButton = [[NSButton alloc] initWithFrame:NSMakeRect(178, 12, 100, 30)];
  [cancelButton setTitle:"Cancel"];
  [cancelButton setBezelStyle:NSRoundedBezelStyle];
  [cancelButton setCOSJSTargetFunction:function(sender) {
    [cancelButton setCOSJSTargetFunction:undefined];
    cancelled = true;
  }];
  [cancelButton setAction:"callAction:"];
  [[progressWindow contentView] addSubview:cancelButton];

  var okButton = [[NSButton alloc] initWithFrame:NSMakeRect(178, 12, 100, 30)];
  [okButton setTitle:"Ok"];
  [okButton setBezelStyle:NSRoundedBezelStyle];
  [okButton setCOSJSTargetFunction:function(sender) {
    [progressWindow orderOut:nil];
    [[app mainWindow] endSheet: progressWindow];
    [okButton setCOSJSTargetFunction:undefined];
    COScript.currentCOScript().setShouldKeepAround_(false);

  }];
  [okButton setAction:"callAction:"];
  [okButton setHidden:true];

  [[progressWindow contentView] addSubview:okButton];

  var progressIndex = 0;
  var sketchData = [];
  var  processor = new MochaJSDelegate({
    "processStep:":(function(timer) {
      try{
        if(cancelled){
          timer.invalidate();
          [progressWindow orderOut:nil];
          [[app mainWindow] endSheet: progressWindow];
          return;
        }
        [activityIndicator setDoubleValue:progressIndex];
        if (progressIndex ==0) {
          [subtitleField setStringValue:"Gathering project information..."];
          var subtitleWidth = subtitleField.fittingSize().width;
          subtitleField.frame = NSMakeRect((width-subtitleWidth)/2, 44,subtitleWidth, 25);
          unzipJIMFile(tempFolder);
        }else if(progressIndex<(progressCount-1)){
          var artboard=artboardsToExport[progressIndex-1];
          [subtitleField setStringValue:"Exporting '"+artboard.name+"' ..."];
          var subtitleWidth = subtitleField.fittingSize().width;
          subtitleField.frame = NSMakeRect((width-subtitleWidth)/2, 44,subtitleWidth, 25);
          sketchData.push(getArtboardData(artboard));
        }else if(progressIndex==(progressCount-1)){
           [subtitleField setStringValue:"Creating Justinmind file..."];
           var subtitleWidth = subtitleField.fittingSize().width;
           subtitleField.frame = NSMakeRect((width-subtitleWidth)/2, 44,subtitleWidth, 25);
          createJustinmindFile(sketchData,tempFolder,jimFile);
        }

        if (progressIndex > progressCount && !cancelled) {
          timer.invalidate();
          [titleField setStringValue:"Artboards exported succesfully!"];
          var titleWidth = titleField.fittingSize().width;
          titleField.frame = NSMakeRect((width-titleWidth)/2, 72,titleWidth, 20);
          [cancelButton setHidden:true];
          [okButton setHidden:false];
          [activityIndicator setHidden:true];
          [subtitleField setHidden:true];
        }
        progressIndex++;
      }catch(e) {
        timer.invalidate();
        [titleField setStringValue:"Export failed!"];
        var titleWidth = titleField.fittingSize().width;
        titleField.frame = NSMakeRect((width-titleWidth)/2, 72,titleWidth, 20);
        alert("Error",e);
        [cancelButton setHidden:true];
        [okButton setHidden:false];
        [activityIndicator setHidden:true];
        [subtitleField setHidden:true];
      }
    }),
  });

  var timer = [NSTimer scheduledTimerWithTimeInterval: 0.05 target: processor.getClassInstance() selector: "processStep:" userInfo: nil repeats: true]
  var runLoop = [NSRunLoop currentRunLoop];
  [runLoop addTimer:timer forMode:NSRunLoopCommonModes];
  [[app mainWindow] beginSheet:progressWindow completionHandler:nil];
}

function isSketch79OrGreater(){
  return getSketchVersion() >=79 ? true: false;
}

function isDarkModeEnabled(){
  try{
    return getSketchVersion() >=52 ? ([[[NSApplication sharedApplication] effectiveAppearance] name] ==NSAppearanceNameDarkAqua) : false;
  }catch(e) {
  }
  return false;
}
