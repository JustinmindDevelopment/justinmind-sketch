function exportLayerAsPNG(layer){
  var uuid = NSString.stringWithUUID();
  return exportLayerAsImage(layer,uuid,"png");
}

function exportMaskedLayersAsSVG(parent,indexMask){
  var uuid = NSString.stringWithUUID();
  exportMaskedLayersAsImage(parent,indexMask,uuid,"svg");
  return exportMaskedLayersAsImage(parent,indexMask,uuid,"png");
}

function exportLayerAsSVG(layer){
  var uuid = NSString.stringWithUUID();
  var infoPNG = exportLayerAsImage(layer,uuid,"png");
  var infoSVG = exportLayerAsImage(layer,uuid,"svg");
  return {
    "fileName":infoPNG.fileName,
    "size":infoPNG.size
  };
}

function exportLayerAsImage(layer,uuid,format){
  var fileFolder = getExportImageFolder();
  let originalName = layer.name;
  const options = {
      scales: enableExportImage2X ? '2' : '1',
      formats: format,
      output: fileFolder,
      trimmed: false
  };
  layer.name = uuid;
  sketch.export(layer, options);
  layer.name = originalName;

  var filePath = fileFolder+uuid+"."+format;
  var image = NSImage.alloc().initByReferencingFile(filePath);
  var dimensions = [image size];

  return {
    "fileName":uuid+"."+format,
    "size":{"width":dimensions.width,"height":dimensions.height}
  };
}

function exportMaskedLayersAsImage(parent,indexMask,uuid,format){
  var fileFolder = getExportImageFolder();
  const options = {
      scales: enableExportImage2X ? '2' : '1',
      formats: format,
      output: fileFolder,
      trimmed: false
  };

  var currentArtboard= (isArtboard(parent.type))? parent : parent.getParentArtboard();
  var auxGroup;
  var duplicatedParent;
  var pos;
  try{
     auxGroup = new sketch.Group({
      name: uuid,
      layers: []
    });
    for(var i=0;i<parent.layers.length;i++){
      var layer = parent.layers[i];
      if(i<indexMask){

      }else if(isMask(layer) || hasMask(layer)) {
        var duplicatedLayer = layer.duplicate();
        auxGroup.layers.push(duplicatedLayer);
      }
    }
    auxGroup.adjustToFit();
    sketch.export(auxGroup, options);
    var maskLayer = parent.layers[indexMask];
    pos={"x":maskLayer.frame.x,'y':maskLayer.frame.y};
  }catch(error){
    //adjustToFit crash on Sketch v97
    duplicatedParent = parent.duplicate();
    var toRemoveLayers = [];
    for(var i=0;i<duplicatedParent.layers.length;i++){
      var duplicatedLayer = duplicatedParent.layers[i];
      if(i<indexMask)
        toRemoveLayers.push(duplicatedLayer);
      else if(!isMask(duplicatedLayer) && !hasMask(duplicatedLayer)) {
        toRemoveLayers.push(duplicatedLayer);
      }
    });
    duplicatedParent.name= uuid;
    toRemoveLayers.forEach(layer=>{
      layer.remove();
    });
    sketch.export(duplicatedParent, options);
    pos={"x":0,'y':0};
  }
  if(auxGroup)
    auxGroup.remove();
  if(duplicatedParent)
    duplicatedParent.remove();


  var filePath = fileFolder+uuid+"."+format;
  var image = NSImage.alloc().initByReferencingFile(filePath);
  var dimensions = [image size];
  return {
    "fileName":uuid+"."+format,
    "pos":pos,
    "size":{"width":dimensions.width,"height":dimensions.height}
  };
}



function getExportImageFolder(){
  var path = tempFolder.path()+"/images/";
  return path;
}
